<?php
/** Landing page template (scholarships in Germany, master's scholarships ...). Uses the theme's header, top bar and footer. */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
get_header();
if ( locate_template( 'page-bar.php' ) ) {
	get_template_part( 'page-bar' );
}
echo Scholarwise_SEO::css(); // phpcs:ignore -- static CSS
Scholarwise_SEO::render_hub();
get_footer();
