<?php
/** Sitemap provider for the landing pages: /wp-sitemap-landing-hubs-1.xml */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
class Scholarwise_Hub_Sitemap extends WP_Sitemaps_Provider {
	public function __construct() {
		$this->name        = 'landing';
		$this->object_type = 'hubs';
	}
	public function get_object_subtypes() {
		return array();
	}
	public function get_url_list( $page_num, $object_subtype = '' ) {
		return 1 === (int) $page_num ? Scholarwise_SEO::sitemap_urls() : array();
	}
	public function get_max_num_pages( $object_subtype = '' ) {
		return 1;
	}
}
