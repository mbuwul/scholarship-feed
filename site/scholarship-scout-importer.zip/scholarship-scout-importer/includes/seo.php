<?php
/**
 * Scholar Wise Africa: search engine optimisation.
 *
 * Hooks only, loaded by the main plugin file. Adds:
 * - page titles, meta descriptions, canonical links and robots rules;
 * - Open Graph and Twitter cards for link previews;
 * - schema.org JSON-LD (Organization, WebSite, Article, BreadcrumbList, MonetaryGrant,
 *   JobPosting for internships, EducationalOccupationalProgram for admissions, ItemList on landing pages);
 * - landing pages per category, destination, level and funding (/scholarships/in-germany/ ...);
 * - sitemap improvements (lastmod, landing pages, no expired items, no user pages);
 * - IndexNow pings so Bing, Yandex and others see new pages within minutes;
 * - a crawlable "Browse" block under the front-page app and an "Explore more" block on item pages;
 * - search engine verification codes and an SEO status screen (Settings > Scholar Wise SEO).
 *
 * When Yoast, Rank Math or All in One SEO is active, the head tags and sitemap changes switch off
 * so nothing is printed twice; landing pages, internal links and IndexNow keep working.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Scholarwise_SEO {

	const VERSION    = '1.0.0';
	const OPT        = 'sw_seo';
	const CACHE      = 'sw_seo_items_v1';
	const BRAND      = 'Scholar Wise Africa';
	const MIN_HUB    = 3;   // Landing pages with fewer open items are noindex,follow.
	const STALE_DAYS = 60;  // Item pages are noindexed this long after their deadline.

	private static $queue = array();
	private static $hub   = null;

	/* ---------- Data ---------- */

	/** Landing page roots: slug => [post type, feed type, plural label, audience]. */
	public static function types() {
		return array(
			'scholarships'     => array( 'ss_opportunity', 'scholarship', __( 'Scholarships', 'scholarship-scout' ), 'students' ),
			'fellowships'      => array( 'ss_opportunity', 'fellowship', __( 'Fellowships', 'scholarship-scout' ), 'researchers' ),
			'internships'      => array( 'ss_opportunity', 'internship', __( 'Internships', 'scholarship-scout' ), 'students' ),
			'conferences'      => array( 'ss_opportunity', 'conference', __( 'Funded Conferences', 'scholarship-scout' ), 'researchers' ),
			'calls-for-papers' => array( 'ss_opportunity', 'call_for_papers', __( 'Calls for Papers', 'scholarship-scout' ), 'researchers' ),
			'grants'           => array( 'ss_opportunity', 'grant', __( 'Research Grants', 'scholarship-scout' ), 'researchers' ),
			'open-admissions'  => array( 'ss_admission', '', __( 'Open Admissions', 'scholarship-scout' ), 'students' ),
		);
	}

	public static function levels() {
		return array(
			'undergraduate' => __( 'Undergraduate', 'scholarship-scout' ),
			'masters'       => __( "Master's", 'scholarship-scout' ),
			'phd'           => __( 'PhD', 'scholarship-scout' ),
			'postdoc'       => __( 'Postdoctoral', 'scholarship-scout' ),
		);
	}

	public static function regions() {
		return array( 'europe' => 'Europe', 'asia' => 'Asia', 'north-america' => 'North America' );
	}

	/** Destination countries with their ISO 3166-1 codes (used for landing pages and structured data). */
	public static function countries() {
		return array(
			'Australia' => 'AU', 'Austria' => 'AT', 'Belgium' => 'BE', 'Brazil' => 'BR', 'Bulgaria' => 'BG', 'Canada' => 'CA',
			'Chile' => 'CL', 'China' => 'CN', 'Croatia' => 'HR', 'Cyprus' => 'CY', 'Czechia' => 'CZ', 'Czech Republic' => 'CZ',
			'Denmark' => 'DK', 'Estonia' => 'EE', 'Finland' => 'FI', 'France' => 'FR', 'Germany' => 'DE', 'Greece' => 'GR',
			'Hong Kong' => 'HK', 'Hungary' => 'HU', 'Iceland' => 'IS', 'India' => 'IN', 'Indonesia' => 'ID', 'Ireland' => 'IE',
			'Israel' => 'IL', 'Italy' => 'IT', 'Japan' => 'JP', 'Kazakhstan' => 'KZ', 'Latvia' => 'LV', 'Lithuania' => 'LT',
			'Luxembourg' => 'LU', 'Malaysia' => 'MY', 'Malta' => 'MT', 'Mexico' => 'MX', 'Netherlands' => 'NL', 'New Zealand' => 'NZ',
			'Norway' => 'NO', 'Pakistan' => 'PK', 'Philippines' => 'PH', 'Poland' => 'PL', 'Portugal' => 'PT', 'Qatar' => 'QA',
			'Romania' => 'RO', 'Russia' => 'RU', 'Saudi Arabia' => 'SA', 'Serbia' => 'RS', 'Singapore' => 'SG', 'Slovakia' => 'SK',
			'Slovenia' => 'SI', 'South Korea' => 'KR', 'Korea' => 'KR', 'Spain' => 'ES', 'Sweden' => 'SE', 'Switzerland' => 'CH',
			'Taiwan' => 'TW', 'Thailand' => 'TH', 'Türkiye' => 'TR', 'Turkey' => 'TR', 'United Arab Emirates' => 'AE', 'UAE' => 'AE',
			'United Kingdom' => 'GB', 'UK' => 'GB', 'United States' => 'US', 'USA' => 'US', 'Vietnam' => 'VN', 'Brunei' => 'BN',
			'Kuwait' => 'KW', 'Oman' => 'OM', 'Bahrain' => 'BH', 'Jordan' => 'JO', 'Lebanon' => 'LB', 'Mauritius' => 'MU',
			'South Africa' => 'ZA', 'Egypt' => 'EG', 'Morocco' => 'MA', 'Kenya' => 'KE', 'Ghana' => 'GH', 'Nigeria' => 'NG', 'Rwanda' => 'RW',
		);
	}

	/** Country slug => display name (one name per slug). */
	public static function country_slugs() {
		static $out = null;
		if ( null === $out ) {
			$out   = array();
			$alias = array( 'Czech Republic', 'Korea', 'Turkey', 'UAE', 'UK', 'USA' );
			foreach ( self::countries() as $name => $iso ) {
				if ( ! in_array( $name, $alias, true ) ) {
					$out[ sanitize_title( $name ) ] = $name;
				}
			}
		}
		return $out;
	}

	public static function iso( $country ) {
		$c = self::countries();
		return $c[ trim( (string) $country ) ] ?? '';
	}

	private static function norm_country( $country ) {
		$country = trim( (string) $country );
		$alias   = array( 'Czech Republic' => 'Czechia', 'Korea' => 'South Korea', 'Turkey' => 'Türkiye', 'UAE' => 'United Arab Emirates', 'UK' => 'United Kingdom', 'USA' => 'United States' );
		return $alias[ $country ] ?? $country;
	}

	private static function norm_levels( $s ) {
		$s   = strtolower( (string) $s );
		$out = array();
		if ( preg_match( '/undergrad|bachelor/', $s ) ) {
			$out[] = 'undergraduate';
		}
		if ( preg_match( '/master/', $s ) ) {
			$out[] = 'masters';
		}
		if ( preg_match( '/phd|doctor/', $s ) ) {
			$out[] = 'phd';
		}
		if ( preg_match( '/postdoc/', $s ) ) {
			$out[] = 'postdoc';
		}
		return $out;
	}

	private static function m( $id, $k ) {
		return trim( (string) get_post_meta( $id, 'ss_' . $k, true ) );
	}

	private static function raw( $id ) {
		$r = json_decode( (string) get_post_meta( $id, '_ss_raw', true ), true );
		return is_array( $r ) ? $r : array();
	}

	private static function is_date( $d ) {
		return (bool) preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $d );
	}

	private static function today() {
		return current_time( 'Y-m-d' );
	}

	/** All published items that are still open, with the fields landing pages need. Cached for an hour. */
	public static function items() {
		$c = get_transient( self::CACHE );
		if ( is_array( $c ) ) {
			return $c;
		}
		global $wpdb;
		$keys = array( 'ss_type', 'ss_deadline', 'ss_host_country', 'ss_program_country', 'ss_region', 'ss_levels', 'ss_funding', 'ss_provider', 'ss_university' );
		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			"SELECT p.ID, p.post_type, p.post_date_gmt, p.post_modified_gmt, m.meta_key, m.meta_value FROM {$wpdb->posts} p
			 LEFT JOIN {$wpdb->postmeta} m ON m.post_id = p.ID AND m.meta_key IN ('" . implode( "','", $keys ) . "')
			 WHERE p.post_type IN ('ss_opportunity','ss_admission') AND p.post_status = 'publish'"
		);
		$by = array();
		foreach ( (array) $rows as $r ) {
			$id = (int) $r->ID;
			if ( ! isset( $by[ $id ] ) ) {
				$by[ $id ] = array( 'id' => $id, 'pt' => $r->post_type, 'pub' => $r->post_date_gmt, 'mod' => $r->post_modified_gmt );
			}
			if ( $r->meta_key ) {
				$by[ $id ][ substr( $r->meta_key, 3 ) ] = (string) $r->meta_value;
			}
		}
		$today = self::today();
		$out   = array();
		foreach ( $by as $it ) {
			$dl = trim( $it['deadline'] ?? '' );
			if ( self::is_date( $dl ) && $dl < $today ) {
				continue;
			}
			$country = self::norm_country( 'ss_admission' === $it['pt'] ? ( $it['program_country'] ?? '' ) : ( $it['host_country'] ?? '' ) );
			$out[]   = array(
				'id'      => $it['id'],
				'pt'      => $it['pt'],
				'type'    => 'ss_admission' === $it['pt'] ? '' : strtolower( trim( $it['type'] ?? '' ) ),
				'dl'      => $dl,
				'country' => self::iso( $country ) ? $country : '',
				'cslug'   => self::iso( $country ) ? sanitize_title( $country ) : '',
				'region'  => sanitize_title( $it['region'] ?? '' ),
				'levels'  => self::norm_levels( $it['levels'] ?? '' ),
				'full'    => 'full' === strtolower( trim( $it['funding'] ?? '' ) ),
				'by'      => trim( 'ss_admission' === $it['pt'] ? ( $it['university'] ?? '' ) : ( $it['provider'] ?? '' ) ),
				'pub'     => $it['pub'],
				'mod'     => $it['mod'],
			);
		}
		usort( $out, function ( $a, $b ) {
			$x = self::is_date( $a['dl'] ) ? $a['dl'] : '9999';
			$y = self::is_date( $b['dl'] ) ? $b['dl'] : '9999';
			return strcmp( $x, $y );
		} );
		set_transient( self::CACHE, $out, HOUR_IN_SECONDS );
		return $out;
	}

	public static function flush( $post_id = 0 ) {
		if ( ! $post_id || in_array( get_post_type( $post_id ), array( 'ss_opportunity', 'ss_admission' ), true ) ) {
			delete_transient( self::CACHE );
		}
	}

	/** Filter kinds each root supports (levels make no sense for conferences or calls for papers). */
	private static function allows( $root, $f ) {
		if ( 'fully-funded' === $f ) {
			return in_array( $root, array( 'scholarships', 'fellowships', 'internships', 'conferences' ), true );
		}
		if ( isset( self::levels()[ $f ] ) ) {
			return ! in_array( $root, array( 'conferences', 'calls-for-papers' ), true );
		}
		return true;
	}

	/** Is the filter valid for this landing page root? */
	private static function valid_filter( $root, $f ) {
		if ( '' === $f ) {
			return true;
		}
		if ( ! self::allows( $root, $f ) ) {
			return false;
		}
		if ( 'fully-funded' === $f || isset( self::levels()[ $f ] ) ) {
			return true;
		}
		if ( 0 === strpos( $f, 'in-' ) ) {
			$s = substr( $f, 3 );
			return isset( self::regions()[ $s ] ) || isset( self::country_slugs()[ $s ] );
		}
		return false;
	}

	/** Open items on one landing page. */
	public static function hub_items( $root, $f = '' ) {
		$t = self::types()[ $root ] ?? null;
		if ( ! $t ) {
			return array();
		}
		return array_values( array_filter( self::items(), function ( $it ) use ( $t, $f ) {
			if ( $it['pt'] !== $t[0] || ( $t[1] && $it['type'] !== $t[1] ) ) {
				return false;
			}
			if ( '' === $f ) {
				return true;
			}
			if ( 'fully-funded' === $f ) {
				return $it['full'];
			}
			if ( isset( self::levels()[ $f ] ) ) {
				return in_array( $f, $it['levels'], true );
			}
			$s = substr( $f, 3 );
			return isset( self::regions()[ $s ] ) ? $it['region'] === $s : $it['cslug'] === $s;
		} ) );
	}

	public static function hub_url( $root, $f = '' ) {
		return home_url( '/' . $root . '/' . ( $f ? $f . '/' : '' ) );
	}

	/** Every landing page with its count: [root, filter, count]. */
	public static function all_hubs() {
		$counts = array();
		foreach ( self::types() as $root => $t ) {
			$counts[ $root . '|' ] = 0;
		}
		foreach ( self::items() as $it ) {
			foreach ( self::types() as $root => $t ) {
				if ( $it['pt'] !== $t[0] || ( $t[1] && $it['type'] !== $t[1] ) ) {
					continue;
				}
				$fs = array( '' );
				if ( $it['cslug'] ) {
					$fs[] = 'in-' . $it['cslug'];
				}
				if ( isset( self::regions()[ $it['region'] ] ) ) {
					$fs[] = 'in-' . $it['region'];
				}
				foreach ( $it['levels'] as $l ) {
					$fs[] = $l;
				}
				if ( $it['full'] && 'open-admissions' !== $root ) {
					$fs[] = 'fully-funded';
				}
				foreach ( $fs as $f ) {
					if ( ! self::allows( $root, $f ) ) {
						continue;
					}
					$counts[ $root . '|' . $f ] = ( $counts[ $root . '|' . $f ] ?? 0 ) + 1;
				}
			}
		}
		$out = array();
		foreach ( $counts as $k => $n ) {
			list( $root, $f ) = explode( '|', $k, 2 );
			$out[]            = array( $root, $f, $n );
		}
		return $out;
	}

	private static function hub_count( $root, $f ) {
		foreach ( self::all_hubs() as $h ) {
			if ( $h[0] === $root && $h[1] === $f ) {
				return $h[2];
			}
		}
		return 0;
	}

	/** Heading words for a landing page. */
	public static function hub_label( $root, $f ) {
		$t     = self::types()[ $root ];
		$plain = $t[2];
		$who   = 'researchers' === $t[3] ? __( 'African Students and Researchers', 'scholarship-scout' ) : __( 'African Students', 'scholarship-scout' );
		if ( 'fully-funded' === $f ) {
			return sprintf( __( 'Fully Funded %1$s for %2$s', 'scholarship-scout' ), $plain, $who );
		}
		if ( isset( self::levels()[ $f ] ) ) {
			return sprintf( __( '%1$s %2$s for %3$s', 'scholarship-scout' ), self::levels()[ $f ], $plain, $who );
		}
		if ( 0 === strpos( $f, 'in-' ) ) {
			$s     = substr( $f, 3 );
			$place = self::regions()[ $s ] ?? ( self::country_slugs()[ $s ] ?? $s );
			if ( in_array( $place, array( 'United States', 'United Kingdom', 'Netherlands', 'United Arab Emirates', 'Philippines' ), true ) ) {
				$place = 'the ' . $place;
			}
			return sprintf( __( '%1$s in %2$s for %3$s', 'scholarship-scout' ), $plain, $place, $who );
		}
		return sprintf( __( '%1$s for %2$s', 'scholarship-scout' ), $plain, $who );
	}

	private static function years() {
		$y = (int) current_time( 'Y' );
		return $y . '–' . ( $y + 1 );
	}

	/* ---------- Hooks ---------- */

	public static function init() {
		add_action( 'init', array( __CLASS__, 'rewrites' ) );
		add_action( 'init', array( __CLASS__, 'maybe_flush' ), 99 );
		add_action( 'init', array( __CLASS__, 'indexnow_key_file' ), 0 );
		add_filter( 'query_vars', function ( $v ) {
			$v[] = 'sw_hub';
			$v[] = 'sw_hub_f';
			return $v;
		} );
		add_action( 'parse_query', array( __CLASS__, 'parse_query' ) );
		add_filter( 'posts_pre_query', array( __CLASS__, 'skip_hub_query' ), 10, 2 );
		add_filter( 'pre_handle_404', function ( $pre ) {
			return self::$hub ? true : $pre;
		} );
		add_filter( 'template_include', array( __CLASS__, 'hub_template' ), 99 );
		add_action( 'template_redirect', function () {
			if ( ! self::$hub && '' !== (string) get_query_var( 'sw_hub' ) ) {
				global $wp_query;
				$wp_query->set_404();
				status_header( 404 );
				nocache_headers();
			}
		}, 0 );
		add_filter( 'body_class', function ( $c ) {
			if ( self::$hub ) {
				$c[] = 'sw-hub-page';
			}
			return $c;
		} );

		add_action( 'save_post', array( __CLASS__, 'flush' ) );
		add_action( 'deleted_post', array( __CLASS__, 'flush' ) );
		add_action( 'ss_importer_after_run', array( __CLASS__, 'flush' ) );
		add_action( 'transition_post_status', array( __CLASS__, 'queue_ping' ), 10, 3 );
		add_action( 'ss_cover_ready', array( __CLASS__, 'queue_post' ) );
		add_action( 'shutdown', array( __CLASS__, 'send_pings' ) );

		add_filter( 'the_content', array( __CLASS__, 'explore_block' ), 9 );
		add_action( 'get_footer', array( __CLASS__, 'front_browse_block' ) );
		add_filter( 'request', array( __CLASS__, 'feed_types' ) );

		add_action( 'admin_menu', array( __CLASS__, 'admin_menu' ) );
		add_action( 'admin_post_sw_seo_save', array( __CLASS__, 'save_settings' ) );
		add_action( 'admin_notices', array( __CLASS__, 'admin_notice' ) );

		// Speed: trim what WordPress adds to every page.
		remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
		remove_action( 'wp_print_styles', 'print_emoji_styles' );
		remove_action( 'wp_head', 'wp_generator' );
		remove_action( 'wp_head', 'wlwmanifest_link' );
		remove_action( 'wp_head', 'rsd_link' );
		remove_action( 'wp_head', 'wp_shortlink_wp_head' );
		add_filter( 'wp_resource_hints', array( __CLASS__, 'resource_hints' ), 10, 2 );

		add_action( 'plugins_loaded', array( __CLASS__, 'late_init' ) );
	}

	/** Head tags and sitemap changes, unless another SEO plugin already does them. */
	public static function late_init() {
		if ( self::other_seo_plugin() ) {
			return;
		}
		add_filter( 'document_title_parts', array( __CLASS__, 'title_parts' ), 20 );
		add_filter( 'pre_get_document_title', array( __CLASS__, 'hub_title' ), 20 );
		add_filter( 'document_title_separator', function () {
			return '|';
		} );
		add_action( 'wp_head', array( __CLASS__, 'head' ), 2 );
		add_filter( 'wp_robots', array( __CLASS__, 'robots' ), 20 );
		add_filter( 'robots_txt', array( __CLASS__, 'robots_txt' ), 20, 2 );
		add_filter( 'wp_sitemaps_add_provider', function ( $p, $name ) {
			return 'users' === $name ? false : $p;
		}, 10, 2 );
		add_filter( 'wp_sitemaps_taxonomies', function ( $t ) {
			unset( $t['post_format'] );
			return $t;
		} );
		add_filter( 'wp_sitemaps_posts_entry', function ( $entry, $post ) {
			$entry['lastmod'] = get_post_modified_time( 'c', true, $post );
			return $entry;
		}, 10, 2 );
		add_filter( 'wp_sitemaps_posts_query_args', array( __CLASS__, 'sitemap_query' ), 10, 2 );
		add_action( 'init', array( __CLASS__, 'register_sitemap' ), 20 );
		add_filter( 'wp_sitemaps_max_urls', function () {
			return 1000;
		} );
	}

	public static function other_seo_plugin() {
		return defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || defined( 'AIOSEO_VERSION' ) || defined( 'SEOPRESS_VERSION' );
	}

	public static function opt( $k, $def = '' ) {
		$o = get_option( self::OPT, array() );
		return isset( $o[ $k ] ) && '' !== $o[ $k ] ? $o[ $k ] : $def;
	}

	/* ---------- Landing pages ---------- */

	public static function rewrites() {
		$roots = implode( '|', array_map( 'preg_quote', array_keys( self::types() ) ) );
		add_rewrite_rule( '^(' . $roots . ')/?$', 'index.php?sw_hub=$matches[1]', 'top' );
		add_rewrite_rule( '^(' . $roots . ')/([a-z0-9-]+)/?$', 'index.php?sw_hub=$matches[1]&sw_hub_f=$matches[2]', 'top' );
	}

	public static function maybe_flush() {
		if ( get_option( 'sw_seo_rules' ) !== self::VERSION ) {
			flush_rewrite_rules( false );
			update_option( 'sw_seo_rules', self::VERSION );
		}
	}

	public static function parse_query( $q ) {
		if ( ! $q->is_main_query() || is_admin() ) {
			return;
		}
		$root = (string) $q->get( 'sw_hub' );
		if ( '' === $root ) {
			return;
		}
		$f = sanitize_title( (string) $q->get( 'sw_hub_f' ) );
		if ( ! isset( self::types()[ $root ] ) || ! self::valid_filter( $root, $f ) ) {
			$q->set_404();
			return;
		}
		self::$hub    = array( $root, $f );
		$q->is_home   = false;
		$q->is_404    = false;
		$q->is_page   = false;
		$q->is_archive = false;
	}

	public static function skip_hub_query( $posts, $q ) {
		return ( self::$hub && $q->is_main_query() ) ? array() : $posts;
	}

	public static function hub_template( $tpl ) {
		if ( self::$hub ) {
			status_header( 200 );
			return __DIR__ . '/seo-hub.php';
		}
		return $tpl;
	}

	public static function current_hub() {
		return self::$hub;
	}

	/** Prints a landing page body (called from seo-hub.php between the theme header and footer). */
	public static function render_hub() {
		list( $root, $f ) = self::$hub;
		$items  = self::hub_items( $root, $f );
		$t      = self::types()[ $root ];
		$label  = self::hub_label( $root, $f );
		$n      = count( $items );
		$crumbs = self::hub_crumbs( $root, $f );

		echo '<main class="wrap sw-page sw-hub" id="main">';
		echo '<nav class="sw-crumbs" aria-label="' . esc_attr__( 'Breadcrumb', 'scholarship-scout' ) . '">';
		$last = count( $crumbs ) - 1;
		foreach ( $crumbs as $i => $c ) {
			echo $i === $last ? '<span aria-current="page">' . esc_html( $c[0] ) . '</span>' : '<a href="' . esc_url( $c[1] ) . '">' . esc_html( $c[0] ) . '</a> <span aria-hidden="true">›</span> ';
		}
		echo '</nav>';
		echo '<h1>' . esc_html( $label ) . ' <span class="sw-years">(' . esc_html( self::years() ) . ')</span></h1>';
		echo '<p class="sw-hub-intro">' . esc_html( self::hub_intro( $root, $f, $n ) ) . '</p>';
		echo '<p class="sw-hub-meta">' . esc_html( sprintf( _n( '%d open listing', '%d open listings', $n, 'scholarship-scout' ), $n ) ) . ' · ' . esc_html( sprintf( __( 'Updated %s', 'scholarship-scout' ), wp_date( 'j F Y' ) ) ) . '</p>';

		if ( $items ) {
			_prime_post_caches( wp_list_pluck( array_slice( $items, 0, 150 ), 'id' ), false, true );
			echo '<ol class="sw-hub-list">';
			foreach ( array_slice( $items, 0, 150 ) as $it ) {
				$id   = $it['id'];
				$raw  = self::raw( $id );
				$bits = array_filter( array(
					$it['by'],
					$it['country'] ?: ( $it['region'] ? ( self::regions()[ $it['region'] ] ?? '' ) : '' ),
					$it['levels'] ? implode( ', ', array_map( function ( $l ) {
						return self::levels()[ $l ];
					}, $it['levels'] ) ) : '',
					'ss_admission' === $it['pt'] ? '' : ( $it['full'] ? __( 'Fully funded', 'scholarship-scout' ) : __( 'Partially funded', 'scholarship-scout' ) ),
				) );
				$sum  = self::trim_words( $raw['description'] ?? ( $raw['eligibility_summary'] ?? '' ), 200 );
				echo '<li class="sw-card sw-hub-item"><h2><a href="' . esc_url( get_permalink( $id ) ) . '">' . esc_html( get_the_title( $id ) ) . '</a></h2>';
				echo '<p class="sw-hub-facts">' . esc_html( implode( ' · ', $bits ) ) . '</p>';
				echo '<p class="sw-hub-dl">' . esc_html( self::deadline_text( $it['dl'] ) ) . '</p>';
				if ( $sum ) {
					echo '<p class="sw-hub-sum">' . esc_html( $sum ) . '</p>';
				}
				echo '</li>';
			}
			echo '</ol>';
		} else {
			echo '<div class="sw-card"><p>' . esc_html__( 'Nothing is open here right now. New listings are added every hour, so check back soon or browse the related pages below.', 'scholarship-scout' ) . '</p></div>';
		}

		echo self::related_html( $root, $f ); // phpcs:ignore -- escaped inside
		echo '</main>';
	}

	private static function hub_intro( $root, $f, $n ) {
		$t    = self::types()[ $root ];
		$what = strtolower( $t[2] );
		if ( 'open-admissions' === $root ) {
			$s = __( 'University programmes that are open for applications right now and accept international applicants, including students from across Africa.', 'scholarship-scout' );
		} else {
			$s = sprintf( __( 'Open %s that African applicants can apply for, sorted by the closest deadline first.', 'scholarship-scout' ), $what );
		}
		return $s . ' ' . __( 'Each listing explains who can apply, what it covers and how to apply in plain words, and links to the official page so you can confirm every detail before you apply. New listings are added every hour.', 'scholarship-scout' );
	}

	private static function hub_crumbs( $root, $f ) {
		$c = array( array( __( 'Home', 'scholarship-scout' ), home_url( '/' ) ), array( self::types()[ $root ][2], self::hub_url( $root ) ) );
		if ( $f ) {
			$c[] = array( self::hub_label( $root, $f ), self::hub_url( $root, $f ) );
		}
		return $c;
	}

	/** Links to sibling landing pages that have enough listings. */
	private static function related_html( $root, $f ) {
		$groups = array(
			__( 'By destination', 'scholarship-scout' ) => array(),
			__( 'By level', 'scholarship-scout' )       => array(),
			__( 'Other categories', 'scholarship-scout' ) => array(),
		);
		$hubs   = self::all_hubs();
		usort( $hubs, function ( $a, $b ) {
			return $b[2] - $a[2];
		} );
		foreach ( $hubs as $h ) {
			if ( $h[2] < self::MIN_HUB || ( $h[0] === $root && $h[1] === $f ) ) {
				continue;
			}
			if ( $h[0] === $root && 0 === strpos( $h[1], 'in-' ) ) {
				$groups[ __( 'By destination', 'scholarship-scout' ) ][] = $h;
			} elseif ( $h[0] === $root && ( isset( self::levels()[ $h[1] ] ) || 'fully-funded' === $h[1] || '' === $h[1] ) ) {
				$groups[ __( 'By level', 'scholarship-scout' ) ][] = $h;
			} elseif ( $h[0] !== $root && ( '' === $h[1] || ( $f && $h[1] === $f ) ) ) {
				$groups[ __( 'Other categories', 'scholarship-scout' ) ][] = $h;
			}
		}
		$html = '';
		foreach ( $groups as $title => $list ) {
			if ( ! $list ) {
				continue;
			}
			$html .= '<h3>' . esc_html( $title ) . '</h3><ul class="sw-links">';
			foreach ( array_slice( $list, 0, 24 ) as $h ) {
				$html .= '<li><a href="' . esc_url( self::hub_url( $h[0], $h[1] ) ) . '">' . esc_html( self::short_label( $h[0], $h[1] ) ) . '</a> <small>' . (int) $h[2] . '</small></li>';
			}
			$html .= '</ul>';
		}
		return $html ? '<section class="sw-related"><h2>' . esc_html__( 'Related pages', 'scholarship-scout' ) . '</h2>' . $html . '</section>' : '';
	}

	/** Shorter link text: "Scholarships in Germany", "Master's scholarships". */
	public static function short_label( $root, $f ) {
		$plain = self::types()[ $root ][2];
		if ( '' === $f ) {
			return $plain;
		}
		if ( 'fully-funded' === $f ) {
			return sprintf( __( 'Fully funded %s', 'scholarship-scout' ), strtolower( $plain ) );
		}
		if ( isset( self::levels()[ $f ] ) ) {
			return self::levels()[ $f ] . ' ' . strtolower( $plain );
		}
		$s = substr( $f, 3 );
		return sprintf( __( '%1$s in %2$s', 'scholarship-scout' ), $plain, self::regions()[ $s ] ?? ( self::country_slugs()[ $s ] ?? $s ) );
	}

	private static function deadline_text( $dl ) {
		if ( 'rolling' === strtolower( $dl ) ) {
			return __( 'Deadline: rolling (apply early)', 'scholarship-scout' );
		}
		if ( ! self::is_date( $dl ) ) {
			return __( 'Deadline: see the official page', 'scholarship-scout' );
		}
		$days = (int) floor( ( strtotime( $dl . ' 23:59:59' ) - current_time( 'timestamp' ) ) / DAY_IN_SECONDS );
		$date = wp_date( 'j F Y', strtotime( $dl . ' 12:00:00' ) );
		if ( $days <= 0 ) {
			return sprintf( __( 'Deadline: %s (closes today)', 'scholarship-scout' ), $date );
		}
		return sprintf( _n( 'Deadline: %1$s (%2$d day left)', 'Deadline: %1$s (%2$d days left)', $days, 'scholarship-scout' ), $date, $days );
	}

	private static function trim_words( $s, $max ) {
		$s = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( (string) $s ) ) );
		if ( mb_strlen( $s ) <= $max ) {
			return $s;
		}
		$cut = mb_substr( $s, 0, $max - 1 );
		$sp  = mb_strrpos( $cut, ' ' );
		return rtrim( $sp ? mb_substr( $cut, 0, $sp ) : $cut, " ,.;:-" ) . '…';
	}

	/* ---------- Internal links ---------- */

	/** Landing pages an item belongs to, best first: [label, url]. */
	public static function item_hubs( $id ) {
		$pt   = get_post_type( $id );
		$root = 'open-admissions';
		if ( 'ss_opportunity' === $pt ) {
			$root = '';
			foreach ( self::types() as $r => $t ) {
				if ( $t[1] && $t[1] === strtolower( self::m( $id, 'type' ) ) ) {
					$root = $r;
				}
			}
			if ( ! $root ) {
				return array();
			}
		}
		$country = self::norm_country( 'ss_admission' === $pt ? self::m( $id, 'program_country' ) : self::m( $id, 'host_country' ) );
		$fs      = array();
		if ( self::iso( $country ) ) {
			$fs[] = 'in-' . sanitize_title( $country );
		}
		if ( 'full' === strtolower( self::m( $id, 'funding' ) ) && 'open-admissions' !== $root ) {
			$fs[] = 'fully-funded';
		}
		foreach ( self::norm_levels( self::m( $id, 'levels' ) ) as $l ) {
			$fs[] = $l;
		}
		$r = sanitize_title( self::m( $id, 'region' ) );
		if ( isset( self::regions()[ $r ] ) ) {
			$fs[] = 'in-' . $r;
		}
		$fs[] = '';
		$out  = array();
		foreach ( $fs as $f ) {
			if ( self::hub_count( $root, $f ) >= self::MIN_HUB ) {
				$out[] = array( self::short_label( $root, $f ), self::hub_url( $root, $f ), $root, $f );
			}
		}
		return $out;
	}

	public static function explore_block( $content ) {
		if ( ! is_singular( array( 'ss_opportunity', 'ss_admission' ) ) || ! in_the_loop() || ! is_main_query() ) {
			return $content;
		}
		$links = self::item_hubs( get_the_ID() );
		if ( ! $links ) {
			return $content;
		}
		$li = '';
		foreach ( array_slice( $links, 0, 6 ) as $l ) {
			$li .= '<li><a href="' . esc_url( $l[1] ) . '">' . esc_html( $l[0] ) . '</a></li>';
		}
		return $content . "\n" . '<nav class="sw-explore" aria-label="' . esc_attr__( 'Explore more', 'scholarship-scout' ) . '"><h2>' . esc_html__( 'Explore more for African applicants', 'scholarship-scout' ) . '</h2><ul class="sw-links">' . $li . '</ul></nav>' . "\n";
	}

	/** Server-rendered links under the front-page app, so search engines can reach every landing page and the newest items. */
	public static function front_browse_block() {
		if ( ! is_front_page() || self::$hub ) {
			return;
		}
		$hubs = self::all_hubs();
		usort( $hubs, function ( $a, $b ) {
			return $b[2] - $a[2];
		} );
		$types = $dest = $lvl = array();
		foreach ( $hubs as $h ) {
			if ( $h[2] < self::MIN_HUB ) {
				continue;
			}
			if ( '' === $h[1] ) {
				$types[] = $h;
			} elseif ( 'scholarships' === $h[0] && 0 === strpos( $h[1], 'in-' ) ) {
				$dest[] = $h;
			} elseif ( isset( self::levels()[ $h[1] ] ) || 'fully-funded' === $h[1] ) {
				$lvl[] = $h;
			}
		}
		$items = self::items();
		usort( $items, function ( $a, $b ) {
			return strcmp( $b['pub'], $a['pub'] );
		} );
		$new = array_slice( $items, 0, 16 );
		_prime_post_caches( wp_list_pluck( $new, 'id' ), false, false );

		$list = function ( $hs ) {
			$o = '<ul class="sw-links">';
			foreach ( $hs as $h ) {
				$o .= '<li><a href="' . esc_url( self::hub_url( $h[0], $h[1] ) ) . '">' . esc_html( self::short_label( $h[0], $h[1] ) ) . '</a> <small>' . (int) $h[2] . '</small></li>';
			}
			return $o . '</ul>';
		};
		echo '<section class="wrap sw-browse" aria-labelledby="sw-browse-h">';
		echo self::css(); // phpcs:ignore
		echo '<h2 id="sw-browse-h">' . esc_html__( 'Browse scholarships and opportunities for African students', 'scholarship-scout' ) . '</h2>';
		echo '<p>' . esc_html__( 'Scholar Wise Africa lists scholarships, fellowships, internships, funded conferences, calls for papers, research grants and open university admissions in Europe, Asia and North America that students and researchers from African countries can apply for. Every listing is explained in plain words and links to its official page.', 'scholarship-scout' ) . '</p>';
		if ( $types ) {
			echo '<h3>' . esc_html__( 'By category', 'scholarship-scout' ) . '</h3>' . $list( $types ); // phpcs:ignore
		}
		if ( $dest ) {
			echo '<h3>' . esc_html__( 'Scholarships by destination', 'scholarship-scout' ) . '</h3>' . $list( array_slice( $dest, 0, 30 ) ); // phpcs:ignore
		}
		if ( $lvl ) {
			echo '<h3>' . esc_html__( 'By level and funding', 'scholarship-scout' ) . '</h3>' . $list( array_slice( $lvl, 0, 20 ) ); // phpcs:ignore
		}
		if ( $new ) {
			echo '<h3>' . esc_html__( 'Newest listings', 'scholarship-scout' ) . '</h3><ul class="sw-links sw-links-wide">';
			foreach ( $new as $it ) {
				echo '<li><a href="' . esc_url( get_permalink( $it['id'] ) ) . '">' . esc_html( get_the_title( $it['id'] ) ) . '</a></li>';
			}
			echo '</ul>';
		}
		echo '</section>';
	}

	/** Shared styles for landing pages and link blocks (uses the site's colour tokens when present). */
	public static function css() {
		static $done = false;
		if ( $done ) {
			return '';
		}
		$done = true;
		return '<style>.sw-crumbs{font-size:.88em;color:var(--muted,#6B7587);margin:8px 0 10px}.sw-crumbs a{color:inherit}'
			. '.sw-hub h1{margin:.2em 0 .4em;line-height:1.2}.sw-years{color:var(--muted,#6B7587);font-weight:500}.sw-hub-intro{font-size:1.05em;max-width:760px;color:var(--fg-2,#3B4658)}.sw-hub-meta{font-size:.88em;color:var(--muted,#6B7587)}'
			. '.sw-hub-list{list-style:none;padding:0;margin:18px 0;display:grid;gap:12px}.sw-hub-item h2{font-size:1.08em;margin:0 0 6px;line-height:1.35}.sw-hub-item h2 a{color:var(--fg,#0E1726);text-decoration:none}.sw-hub-item h2 a:hover{color:var(--accent,#2457D6);text-decoration:underline}'
			. '.sw-hub-facts,.sw-hub-dl{margin:2px 0;font-size:.9em;color:var(--fg-2,#3B4658)}.sw-hub-dl{font-weight:600}.sw-hub-sum{margin:6px 0 0;font-size:.93em;color:var(--fg-2,#3B4658)}'
			. '.sw-related,.sw-browse,.sw-explore{margin:28px auto}.sw-browse{padding-top:8px;border-top:1px solid var(--line,#E2E5EB)}.sw-browse p{max-width:820px;color:var(--fg-2,#3B4658)}.sw-related h3,.sw-browse h3{font-size:.95em;margin:18px 0 8px;color:var(--muted,#6B7587);text-transform:uppercase;letter-spacing:.04em}'
			. '.sw-links{list-style:none;padding:0;margin:0;display:flex;flex-wrap:wrap;gap:8px}.sw-links li{margin:0}.sw-links a{display:inline-block;border:1px solid var(--line,#E2E5EB);border-radius:999px;padding:5px 12px;text-decoration:none;color:var(--fg,#0E1726);font-size:.9em;background:var(--card,transparent)}.sw-links a:hover{border-color:var(--accent,#2457D6);color:var(--accent,#2457D6)}.sw-links small{color:var(--muted,#6B7587);font-size:.8em}'
			. '.sw-links-wide{display:block}.sw-links-wide li{margin:6px 0}.sw-links-wide a{border:0;padding:0;border-radius:0;background:none;color:var(--accent,#2457D6)}</style>';
	}

	/** Puts opportunities and admissions in the main RSS feed. */
	public static function feed_types( $q ) {
		if ( isset( $q['feed'] ) && ! isset( $q['post_type'] ) && empty( $q['category_name'] ) && empty( $q['tag'] ) ) {
			$q['post_type'] = array( 'post', 'ss_opportunity', 'ss_admission' );
		}
		return $q;
	}

	/* ---------- Head tags ---------- */

	private static function description( $id ) {
		$raw  = self::raw( $id );
		$text = $raw['description'] ?? '';
		if ( ! $text ) {
			$text = $raw['eligibility_summary'] ?? '';
		}
		if ( ! $text ) {
			$text = get_post_field( 'post_excerpt', $id ) ?: get_post_field( 'post_content', $id );
		}
		$text = self::trim_words( strip_shortcodes( (string) $text ), 400 );
		$dl   = self::m( $id, 'deadline' );
		$tail = self::is_date( $dl ) && $dl >= self::today() ? ' ' . sprintf( __( 'Deadline: %s.', 'scholarship-scout' ), wp_date( 'j M Y', strtotime( $dl . ' 12:00:00' ) ) ) : '';
		return self::trim_words( $text, 158 - mb_strlen( $tail ) ) . $tail;
	}

	public static function title_parts( $parts ) {
		if ( is_front_page() && ! self::$hub ) {
			return array( 'title' => self::BRAND, 'tagline' => __( 'Scholarships and Opportunities for African Students', 'scholarship-scout' ) );
		}
		if ( is_singular( array( 'ss_opportunity', 'ss_admission' ) ) ) {
			$id = get_queried_object_id();
			$dl = self::m( $id, 'deadline' );
			$t  = wp_strip_all_tags( get_the_title( $id ) );
			if ( self::is_date( $dl ) && $dl >= self::today() ) {
				$add = ' – ' . sprintf( __( 'Deadline %s', 'scholarship-scout' ), wp_date( 'j M Y', strtotime( $dl . ' 12:00:00' ) ) );
				if ( mb_strlen( $t . $add ) <= 62 ) {
					$t .= $add;
				}
			}
			$parts['title'] = $t;
			unset( $parts['tagline'] );
		}
		$parts['site'] = self::BRAND;
		return $parts;
	}

	public static function hub_title( $t ) {
		if ( self::$hub ) {
			return self::hub_label( self::$hub[0], self::$hub[1] ) . ' ' . self::years() . ' | ' . self::BRAND;
		}
		return $t;
	}

	private static function canonical() {
		if ( self::$hub ) {
			return self::hub_url( self::$hub[0], self::$hub[1] );
		}
		if ( is_front_page() ) {
			return home_url( '/' );
		}
		if ( is_singular() ) {
			return wp_get_canonical_url( get_queried_object_id() );
		}
		return '';
	}

	private static function image( $id = 0 ) {
		$img = $id ? get_the_post_thumbnail_url( $id, 'full' ) : '';
		return $img ?: plugins_url( 'seo-assets/og-default.png', __FILE__ );
	}

	private static function front_desc() {
		return __( 'Scholarships, fellowships, internships, funded conferences, calls for papers, grants and open admissions for African students in Europe, Asia and North America. Updated every hour.', 'scholarship-scout' );
	}

	public static function head() {
		$o     = '';
		$canon = self::canonical();
		$id    = is_singular() ? get_queried_object_id() : 0;
		$item  = is_singular( array( 'ss_opportunity', 'ss_admission' ) );

		// Verification codes.
		foreach ( array( 'google' => 'google-site-verification', 'bing' => 'msvalidate.01', 'yandex' => 'yandex-verification', 'facebook' => 'facebook-domain-verification', 'pinterest' => 'p:domain_verify' ) as $k => $name ) {
			$v = self::opt( $k );
			if ( $v ) {
				$o .= '<meta name="' . esc_attr( $name ) . '" content="' . esc_attr( $v ) . '">' . "\n";
			}
		}

		if ( self::$hub ) {
			list( $root, $f ) = self::$hub;
			$title = self::hub_label( $root, $f ) . ' ' . self::years();
			$desc  = self::trim_words( sprintf( __( '%1$d open %2$s, sorted by deadline. Who can apply, what is covered and how to apply, explained in plain words with the official link. Updated hourly.', 'scholarship-scout' ), count( self::hub_items( $root, $f ) ), lcfirst( self::hub_label( $root, $f ) ) ), 160 );
			$type  = 'website';
		} elseif ( is_front_page() ) {
			$title = wp_get_document_title();
			$desc  = self::front_desc();
			$type  = 'website';
		} elseif ( $id ) {
			$title = wp_strip_all_tags( get_the_title( $id ) );
			$desc  = $item ? self::description( $id ) : self::trim_words( get_post_field( 'post_excerpt', $id ) ?: strip_shortcodes( get_post_field( 'post_content', $id ) ), 158 );
			$type  = 'article';
		} else {
			$title = wp_get_document_title();
			$desc  = '';
			$type  = 'website';
		}

		if ( $desc ) {
			$o .= '<meta name="description" content="' . esc_attr( $desc ) . '">' . "\n";
		}
		if ( $canon && ! is_singular() ) {
			$o .= '<link rel="canonical" href="' . esc_url( $canon ) . '">' . "\n"; // WordPress prints it on single pages.
		}
		$o .= '<meta name="theme-color" content="#0B1B34">' . "\n";

		$img = self::image( $item ? $id : 0 );
		$og  = array(
			'og:locale'      => str_replace( '-', '_', get_bloginfo( 'language' ) ),
			'og:type'        => $type,
			'og:site_name'   => self::BRAND,
			'og:title'       => $title,
			'og:description' => $desc,
			'og:url'         => $canon,
			'og:image'       => $img,
			'og:image:alt'   => $title,
		);
		if ( ! $item || ! has_post_thumbnail( $id ) ) {
			$og['og:image:width']  = '1200';
			$og['og:image:height'] = '630';
		}
		if ( 'article' === $type && $id ) {
			$og['article:published_time'] = get_post_time( 'c', true, $id );
			$og['article:modified_time']  = get_post_modified_time( 'c', true, $id );
		}
		foreach ( $og as $k => $v ) {
			if ( '' !== (string) $v ) {
				$o .= '<meta property="' . esc_attr( $k ) . '" content="' . esc_attr( $v ) . '">' . "\n";
			}
		}
		$tw = array( 'twitter:card' => 'summary_large_image', 'twitter:title' => $title, 'twitter:description' => $desc, 'twitter:image' => $img );
		$h  = ltrim( (string) self::opt( 'twitter' ), '@' );
		if ( $h ) {
			$tw['twitter:site'] = '@' . $h;
		}
		foreach ( $tw as $k => $v ) {
			if ( '' !== (string) $v ) {
				$o .= '<meta name="' . esc_attr( $k ) . '" content="' . esc_attr( $v ) . '">' . "\n";
			}
		}

		$graph = self::schema( $id, $item, $canon, $title, $desc, $img );
		if ( $graph ) {
			$o .= '<script type="application/ld+json">' . wp_json_encode( array( '@context' => 'https://schema.org', '@graph' => $graph ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
		}
		echo $o; // phpcs:ignore -- every value escaped above
	}

	private static function org() {
		$same = array_values( array_filter( array_map( 'trim', preg_split( '/[\s,]+/', (string) self::opt( 'same_as' ) ) ), function ( $u ) {
			return (bool) wp_http_validate_url( $u );
		} ) );
		$org  = array(
			'@type' => 'Organization',
			'@id'   => home_url( '/#organization' ),
			'name'  => self::BRAND,
			'url'   => home_url( '/' ),
			'logo'  => array( '@type' => 'ImageObject', 'url' => self::opt( 'logo', plugins_url( 'seo-assets/logo.png', __FILE__ ) ), 'width' => 512, 'height' => 512 ),
			'description' => self::front_desc(),
		);
		if ( $same ) {
			$org['sameAs'] = $same;
		}
		$email = sanitize_email( (string) self::opt( 'email' ) );
		if ( $email ) {
			$org['email'] = $email;
		}
		return $org;
	}

	private static function crumbs_ld( $crumbs, $url ) {
		$list = array();
		foreach ( $crumbs as $i => $c ) {
			$list[] = array( '@type' => 'ListItem', 'position' => $i + 1, 'name' => $c[0], 'item' => $c[1] );
		}
		return array( '@type' => 'BreadcrumbList', '@id' => $url . '#breadcrumb', 'itemListElement' => $list );
	}

	private static function schema( $id, $item, $url, $title, $desc, $img ) {
		$g   = array( self::org() );
		$g[] = array(
			'@type'     => 'WebSite',
			'@id'       => home_url( '/#website' ),
			'url'       => home_url( '/' ),
			'name'      => self::BRAND,
			'publisher' => array( '@id' => home_url( '/#organization' ) ),
			'inLanguage' => get_bloginfo( 'language' ),
			'potentialAction' => array(
				'@type'       => 'SearchAction',
				'target'      => array( '@type' => 'EntryPoint', 'urlTemplate' => home_url( '/?q={search_term_string}' ) ),
				'query-input' => 'required name=search_term_string',
			),
		);
		if ( ! $url ) {
			return $g;
		}

		if ( self::$hub ) {
			list( $root, $f ) = self::$hub;
			$g[]   = self::crumbs_ld( self::hub_crumbs( $root, $f ), $url );
			$items = array_slice( self::hub_items( $root, $f ), 0, 50 );
			$list  = array();
			foreach ( $items as $i => $it ) {
				$list[] = array( '@type' => 'ListItem', 'position' => $i + 1, 'url' => get_permalink( $it['id'] ), 'name' => wp_strip_all_tags( get_the_title( $it['id'] ) ) );
			}
			$g[] = array(
				'@type'       => 'CollectionPage',
				'@id'         => $url . '#webpage',
				'url'         => $url,
				'name'        => $title,
				'description' => $desc,
				'isPartOf'    => array( '@id' => home_url( '/#website' ) ),
				'breadcrumb'  => array( '@id' => $url . '#breadcrumb' ),
				'mainEntity'  => array( '@type' => 'ItemList', 'numberOfItems' => count( $list ), 'itemListElement' => $list ),
			);
			return $g;
		}

		if ( is_front_page() ) {
			$g[] = array( '@type' => 'WebPage', '@id' => $url . '#webpage', 'url' => $url, 'name' => $title, 'description' => $desc, 'isPartOf' => array( '@id' => home_url( '/#website' ) ), 'about' => array( '@id' => home_url( '/#organization' ) ) );
			return $g;
		}
		if ( ! $id ) {
			return $g;
		}

		$crumbs = array( array( __( 'Home', 'scholarship-scout' ), home_url( '/' ) ) );
		if ( $item ) {
			$hubs = self::item_hubs( $id );
			$main = null;
			foreach ( $hubs as $h ) {
				if ( '' === $h[3] ) {
					$main = $h;
				}
			}
			if ( $main ) {
				$crumbs[] = array( $main[0], $main[1] );
				foreach ( $hubs as $h ) {
					if ( 0 === strpos( $h[3], 'in-' ) ) {
						$crumbs[] = array( $h[0], $h[1] );
						break;
					}
				}
			}
		}
		$crumbs[] = array( $title, $url );
		$g[]      = self::crumbs_ld( $crumbs, $url );

		$pub = get_post_time( 'c', true, $id );
		$mod = get_post_modified_time( 'c', true, $id );
		$g[] = array(
			'@type'      => 'WebPage',
			'@id'        => $url . '#webpage',
			'url'        => $url,
			'name'       => $title,
			'description' => $desc,
			'isPartOf'   => array( '@id' => home_url( '/#website' ) ),
			'breadcrumb' => array( '@id' => $url . '#breadcrumb' ),
			'primaryImageOfPage' => array( '@type' => 'ImageObject', 'url' => $img ),
			'datePublished' => $pub,
			'dateModified'  => $mod,
		);
		$article = array(
			'@type'            => 'Article',
			'@id'              => $url . '#article',
			'headline'         => mb_substr( $title, 0, 110 ),
			'description'      => $desc,
			'image'            => array( $img ),
			'datePublished'    => $pub,
			'dateModified'     => $mod,
			'author'           => array( '@type' => 'Organization', 'name' => self::BRAND, 'url' => home_url( '/' ) ),
			'publisher'        => array( '@id' => home_url( '/#organization' ) ),
			'mainEntityOfPage' => array( '@id' => $url . '#webpage' ),
			'inLanguage'       => get_bloginfo( 'language' ),
		);
		if ( ! $item ) {
			$g[] = $article;
			return $g;
		}

		$pt       = get_post_type( $id );
		$official = self::m( $id, 'url' );
		$dl       = self::m( $id, 'deadline' );
		$open     = ! self::is_date( $dl ) || $dl >= self::today();
		$country  = self::norm_country( 'ss_admission' === $pt ? self::m( $id, 'program_country' ) : self::m( $id, 'host_country' ) );
		$iso      = self::iso( $country );
		$type     = strtolower( self::m( $id, 'type' ) );
		$by       = 'ss_admission' === $pt ? self::m( $id, 'university' ) : self::m( $id, 'provider' );
		$raw      = self::raw( $id );

		$article['articleSection'] = 'ss_admission' === $pt ? 'Open admissions' : ( Scholarship_Scout_Importer::label( $type ) ?: 'Opportunities' );
		$kw = array_filter( array_map( 'trim', explode( ',', self::m( $id, 'fields' ) . ',' . self::m( $id, 'levels' ) ) ) );
		if ( $kw ) {
			$article['keywords'] = implode( ', ', array_slice( array_unique( $kw ), 0, 12 ) );
		}

		if ( 'ss_admission' === $pt ) {
			$prog = array(
				'@type'       => 'EducationalOccupationalProgram',
				'@id'         => $url . '#program',
				'name'        => $title,
				'description' => $desc,
				'url'         => $url,
				'sameAs'      => $official ?: null,
				'provider'    => $by ? array_filter( array(
					'@type'   => 'CollegeOrUniversity',
					'name'    => $by,
					'address' => $iso ? array_filter( array( '@type' => 'PostalAddress', 'addressLocality' => self::m( $id, 'city' ) ?: null, 'addressCountry' => $iso ) ) : null,
				) ) : null,
				'applicationDeadline' => self::is_date( $dl ) ? $dl : null,
				'applicationStartDate' => self::is_date( $raw['opens'] ?? '' ) ? $raw['opens'] : null,
				'inLanguage'  => self::m( $id, 'languages' ) ?: null,
				'educationalCredentialAwarded' => ! empty( $raw['degree_names'] ) && is_array( $raw['degree_names'] ) ? implode( ', ', array_slice( $raw['degree_names'], 0, 6 ) ) : null,
			);
			$g[]   = array_filter( $prog, function ( $v ) {
				return null !== $v && '' !== $v;
			} );
			$article['about'] = array( '@id' => $url . '#program' );
		} elseif ( 'internship' === $type ) {
			if ( $open && self::is_date( $dl ) && $iso && $by ) {
				$body = trim( wp_kses( apply_filters( 'ss_raw_content', wpautop( get_post_field( 'post_content', $id ) ) ), array( 'p' => array(), 'br' => array(), 'ul' => array(), 'ol' => array(), 'li' => array(), 'strong' => array(), 'em' => array(), 'h2' => array(), 'h3' => array() ) ) );
				$g[]  = array(
					'@type'          => 'JobPosting',
					'@id'            => $url . '#job',
					'title'          => $title,
					'description'    => $body ?: $desc,
					'datePosted'     => $pub,
					'validThrough'   => $dl . 'T23:59:59+00:00',
					'employmentType' => 'INTERN',
					'hiringOrganization' => array_filter( array( '@type' => 'Organization', 'name' => $by, 'sameAs' => $official ? 'https://' . wp_parse_url( $official, PHP_URL_HOST ) : null ) ),
					'jobLocation'    => array( '@type' => 'Place', 'address' => array( '@type' => 'PostalAddress', 'addressCountry' => $iso ) ),
					'directApply'    => false,
					'url'            => $url,
				);
				$article['about'] = array( '@id' => $url . '#job' );
			}
		} else {
			$grant = array_filter( array(
				'@type'       => 'MonetaryGrant',
				'@id'         => $url . '#grant',
				'name'        => $title,
				'description' => $desc,
				'url'         => $official ?: $url,
				'funder'      => $by ? array( '@type' => 'Organization', 'name' => $by ) : null,
			) );
			$g[]   = $grant;
			$article['about'] = array( '@id' => $url . '#grant' );
		}
		$g[] = $article;
		return $g;
	}

	public static function robots( $r ) {
		if ( ! get_option( 'blog_public' ) ) {
			return $r;
		}
		$noindex = is_search() || is_author() || is_date() || is_attachment() || is_404();
		if ( self::$hub && count( self::hub_items( self::$hub[0], self::$hub[1] ) ) < self::MIN_HUB ) {
			$noindex = true;
		}
		if ( is_singular( array( 'ss_opportunity', 'ss_admission' ) ) ) {
			$dl = self::m( get_queried_object_id(), 'deadline' );
			if ( self::is_date( $dl ) && strtotime( $dl . ' 12:00:00' ) < current_time( 'timestamp' ) - self::STALE_DAYS * DAY_IN_SECONDS ) {
				$noindex = true;
			}
		}
		if ( $noindex ) {
			unset( $r['max-image-preview'] );
			$r['noindex'] = true;
			$r['follow']  = true;
		} else {
			$r['index']             = true;
			$r['follow']            = true;
			$r['max-image-preview'] = 'large';
			$r['max-snippet']       = '-1';
			$r['max-video-preview'] = '-1';
		}
		return $r;
	}

	public static function robots_txt( $out, $public ) {
		if ( ! $public ) {
			return $out;
		}
		$add = "Disallow: /?s=\nDisallow: /search/\nDisallow: /wp-login.php\n";
		if ( false === strpos( $out, 'Disallow: /?s=' ) ) {
			$out = preg_replace( '/(User-agent: \*\n)/', "$1" . $add, $out, 1 );
		}
		if ( false === stripos( $out, 'Sitemap:' ) ) {
			$out .= "\nSitemap: " . home_url( '/wp-sitemap.xml' ) . "\n";
		}
		return $out;
	}

	/** Leaves items more than STALE_DAYS past their deadline out of the sitemap. */
	public static function sitemap_query( $args, $post_type ) {
		if ( in_array( $post_type, array( 'ss_opportunity', 'ss_admission' ), true ) ) {
			$cut                = wp_date( 'Y-m-d', current_time( 'timestamp' ) - self::STALE_DAYS * DAY_IN_SECONDS );
			$args['meta_query'] = array(
				'relation' => 'OR',
				array( 'key' => 'ss_deadline', 'compare' => 'NOT EXISTS' ),
				array( 'key' => 'ss_deadline', 'value' => '^[0-9]{4}-', 'compare' => 'NOT REGEXP' ),
				array( 'key' => 'ss_deadline', 'value' => $cut, 'compare' => '>=' ),
			);
		}
		return $args;
	}

	public static function register_sitemap() {
		if ( ! function_exists( 'wp_register_sitemap_provider' ) || ! class_exists( 'WP_Sitemaps_Provider' ) ) {
			return;
		}
		require_once __DIR__ . '/seo-sitemap.php';
		wp_register_sitemap_provider( 'landing', new Scholarwise_Hub_Sitemap() );
	}

	/** Landing pages for the sitemap: only those with enough listings. */
	public static function sitemap_urls() {
		$out  = array();
		$last = array();
		foreach ( self::items() as $it ) {
			$last[] = $it['mod'];
		}
		$lm = $last ? gmdate( 'c', strtotime( max( $last ) . ' UTC' ) ) : gmdate( 'c' );
		foreach ( self::all_hubs() as $h ) {
			if ( $h[2] >= self::MIN_HUB ) {
				$out[] = array( 'loc' => self::hub_url( $h[0], $h[1] ), 'lastmod' => $lm );
			}
		}
		return $out;
	}

	public static function resource_hints( $urls, $rel ) {
		if ( 'preconnect' === $rel ) {
			$urls[] = 'https://fonts.googleapis.com';
			$urls[] = array( 'href' => 'https://fonts.gstatic.com', 'crossorigin' );
		}
		return $urls;
	}

	/* ---------- IndexNow (Bing, Yandex, Seznam, Naver) ---------- */

	public static function indexnow_key() {
		$k = get_option( 'sw_indexnow_key' );
		if ( ! $k ) {
			$k = wp_generate_password( 32, false, false );
			$k = strtolower( preg_replace( '/[^a-zA-Z0-9]/', '', $k ) );
			update_option( 'sw_indexnow_key', $k, false );
		}
		return $k;
	}

	/** Serves /<key>.txt so search engines can confirm the pings come from this site. */
	public static function indexnow_key_file() {
		$path = wp_parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH ); // phpcs:ignore
		$k    = get_option( 'sw_indexnow_key' );
		if ( $k && $path && rtrim( wp_parse_url( home_url( '/' ), PHP_URL_PATH ) ?: '/', '/' ) . '/' . $k . '.txt' === $path ) {
			header( 'Content-Type: text/plain; charset=utf-8' );
			echo esc_html( $k );
			exit;
		}
	}

	public static function queue_ping( $new, $old, $post ) {
		if ( 'publish' !== $new && 'publish' !== $old ) {
			return;
		}
		if ( ! in_array( $post->post_type, array( 'ss_opportunity', 'ss_admission', 'post', 'page' ), true ) || wp_is_post_revision( $post ) ) {
			return;
		}
		self::queue_post( $post->ID );
	}

	public static function queue_post( $post_id ) {
		$url = get_permalink( $post_id );
		if ( $url ) {
			self::$queue[ $url ] = 1;
		}
		foreach ( self::item_hubs( $post_id ) as $h ) {
			if ( '' === $h[3] ) {
				self::$queue[ $h[1] ] = 1;
			}
		}
	}

	public static function send_pings() {
		if ( ! self::$queue || ! get_option( 'blog_public' ) || 'off' === self::opt( 'indexnow', 'on' ) ) {
			return;
		}
		$host = wp_parse_url( home_url( '/' ), PHP_URL_HOST );
		if ( ! $host || preg_match( '/^(localhost|127\.|10\.|192\.168\.)|\.local$|\.test$/', $host ) ) {
			return;
		}
		$key  = self::indexnow_key();
		$urls = array_slice( array_keys( self::$queue ), 0, 10000 );
		wp_remote_post( 'https://api.indexnow.org/indexnow', array(
			'blocking' => false,
			'timeout'  => 5,
			'headers'  => array( 'Content-Type' => 'application/json; charset=utf-8' ),
			'body'     => wp_json_encode( array( 'host' => $host, 'key' => $key, 'keyLocation' => home_url( '/' . $key . '.txt' ), 'urlList' => $urls ) ),
		) );
		$log   = get_option( 'sw_indexnow_log', array() );
		$log[] = array( 't' => time(), 'n' => count( $urls ) );
		update_option( 'sw_indexnow_log', array_slice( $log, -20 ), false );
		self::$queue = array();
	}

	/* ---------- Settings screen ---------- */

	public static function admin_menu() {
		add_options_page( __( 'Scholar Wise SEO', 'scholarship-scout' ), __( 'Scholar Wise SEO', 'scholarship-scout' ), 'manage_options', 'sw-seo', array( __CLASS__, 'settings_page' ) );
	}

	public static function admin_notice() {
		if ( current_user_can( 'manage_options' ) && ! get_option( 'blog_public' ) ) {
			echo '<div class="notice notice-error"><p><strong>' . esc_html__( 'Search engines are blocked from this site.', 'scholarship-scout' ) . '</strong> ' . esc_html__( 'Go to Settings > Reading and untick "Discourage search engines from indexing this site", or Google will not list any page.', 'scholarship-scout' ) . ' <a href="' . esc_url( admin_url( 'options-reading.php' ) ) . '">' . esc_html__( 'Open Reading settings', 'scholarship-scout' ) . '</a></p></div>';
		}
	}

	public static function settings_page() {
		$fields = array(
			'google'    => array( __( 'Google Search Console verification code', 'scholarship-scout' ), __( 'Only the content="..." value from the HTML tag method.', 'scholarship-scout' ) ),
			'bing'      => array( __( 'Bing Webmaster Tools verification code', 'scholarship-scout' ), __( 'The content value of the msvalidate.01 tag. Not needed if you import from Google Search Console.', 'scholarship-scout' ) ),
			'yandex'    => array( __( 'Yandex verification code (optional)', 'scholarship-scout' ), '' ),
			'facebook'  => array( __( 'Facebook domain verification code (optional)', 'scholarship-scout' ), '' ),
			'pinterest' => array( __( 'Pinterest verification code (optional)', 'scholarship-scout' ), '' ),
			'twitter'   => array( __( 'X (Twitter) handle (optional)', 'scholarship-scout' ), __( 'For example @scholarwiseafrica', 'scholarship-scout' ) ),
			'email'     => array( __( 'Public contact email (optional)', 'scholarship-scout' ), '' ),
			'same_as'   => array( __( 'Your social media pages, one per line (optional)', 'scholarship-scout' ), __( 'Facebook, LinkedIn, X, Telegram, WhatsApp channel, YouTube. Google uses these to connect them to your site.', 'scholarship-scout' ) ),
		);
		$key  = self::indexnow_key();
		$hubs = array_filter( self::all_hubs(), function ( $h ) {
			return $h[2] >= self::MIN_HUB;
		} );
		$log  = get_option( 'sw_indexnow_log', array() );
		$ok   = function ( $b ) {
			return $b ? '<span style="color:#0a7d33">&#10004;</span> ' : '<span style="color:#b32d2e">&#10008;</span> ';
		};
		echo '<div class="wrap"><h1>' . esc_html__( 'Scholar Wise SEO', 'scholarship-scout' ) . '</h1>';
		if ( isset( $_GET['saved'] ) ) { // phpcs:ignore
			echo '<div class="notice notice-success"><p>' . esc_html__( 'Saved.', 'scholarship-scout' ) . '</p></div>';
		}
		if ( self::other_seo_plugin() ) {
			echo '<div class="notice notice-warning"><p>' . esc_html__( 'Another SEO plugin is active, so titles, descriptions, social previews, structured data and sitemap changes from this screen are switched off to avoid duplicates. Landing pages, internal links and IndexNow still work.', 'scholarship-scout' ) . '</p></div>';
		}
		echo '<h2>' . esc_html__( 'Status', 'scholarship-scout' ) . '</h2><ul>';
		echo '<li>' . $ok( get_option( 'blog_public' ) ) . esc_html__( 'Search engines allowed (Settings > Reading)', 'scholarship-scout' ) . '</li>'; // phpcs:ignore
		echo '<li>' . $ok( (bool) get_option( 'permalink_structure' ) ) . esc_html__( 'Readable page addresses (Settings > Permalinks)', 'scholarship-scout' ) . '</li>'; // phpcs:ignore
		echo '<li>' . $ok( is_ssl() || 0 === strpos( home_url(), 'https://' ) ) . esc_html__( 'Site address uses https', 'scholarship-scout' ) . '</li>'; // phpcs:ignore
		echo '<li>' . $ok( (bool) self::opt( 'google' ) ) . esc_html__( 'Google verification code added', 'scholarship-scout' ) . '</li>'; // phpcs:ignore
		echo '<li>' . esc_html( sprintf( __( 'Sitemap: %s', 'scholarship-scout' ), home_url( '/wp-sitemap.xml' ) ) ) . ' (<a href="' . esc_url( home_url( '/wp-sitemap.xml' ) ) . '" target="_blank">' . esc_html__( 'open', 'scholarship-scout' ) . '</a>)</li>';
		echo '<li>' . esc_html( sprintf( __( '%1$d open listings, %2$d landing pages in the sitemap', 'scholarship-scout' ), count( self::items() ), count( $hubs ) ) ) . '</li>';
		echo '<li>' . esc_html( sprintf( __( 'IndexNow key file: %s', 'scholarship-scout' ), home_url( '/' . $key . '.txt' ) ) ) . '</li>';
		if ( $log ) {
			$l = end( $log );
			echo '<li>' . esc_html( sprintf( __( 'Last IndexNow ping: %1$s, %2$d addresses', 'scholarship-scout' ), wp_date( 'j M Y H:i', $l['t'] ), $l['n'] ) ) . '</li>';
		}
		echo '</ul>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="sw_seo_save">';
		wp_nonce_field( 'sw_seo_save' );
		echo '<table class="form-table">';
		foreach ( $fields as $k => $f ) {
			echo '<tr><th><label for="sw-' . esc_attr( $k ) . '">' . esc_html( $f[0] ) . '</label></th><td>';
			if ( 'same_as' === $k ) {
				echo '<textarea id="sw-' . esc_attr( $k ) . '" name="sw[' . esc_attr( $k ) . ']" rows="5" class="large-text">' . esc_textarea( self::opt( $k ) ) . '</textarea>';
			} else {
				echo '<input id="sw-' . esc_attr( $k ) . '" name="sw[' . esc_attr( $k ) . ']" class="regular-text" value="' . esc_attr( self::opt( $k ) ) . '">';
			}
			echo $f[1] ? '<p class="description">' . esc_html( $f[1] ) . '</p>' : '';
			echo '</td></tr>';
		}
		echo '<tr><th>' . esc_html__( 'Tell Bing and others about new pages instantly (IndexNow)', 'scholarship-scout' ) . '</th><td><label><input type="checkbox" name="sw[indexnow]" value="on" ' . checked( 'on', self::opt( 'indexnow', 'on' ), false ) . '> ' . esc_html__( 'On', 'scholarship-scout' ) . '</label></td></tr>';
		echo '</table>';
		submit_button();
		echo '</form>';
		echo '<h2>' . esc_html__( 'Landing pages', 'scholarship-scout' ) . '</h2><p>' . esc_html__( 'These pages are built automatically from your published listings. Pages with fewer than 3 open listings are hidden from search engines until they fill up.', 'scholarship-scout' ) . '</p><ul style="columns:3">';
		usort( $hubs, function ( $a, $b ) {
			return $b[2] - $a[2];
		} );
		foreach ( $hubs as $h ) {
			echo '<li><a href="' . esc_url( self::hub_url( $h[0], $h[1] ) ) . '" target="_blank">' . esc_html( self::short_label( $h[0], $h[1] ) ) . '</a> (' . (int) $h[2] . ')</li>';
		}
		echo '</ul></div>';
	}

	public static function save_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Forbidden' );
		}
		check_admin_referer( 'sw_seo_save' );
		$in  = isset( $_POST['sw'] ) && is_array( $_POST['sw'] ) ? wp_unslash( $_POST['sw'] ) : array(); // phpcs:ignore
		$out = array();
		foreach ( array( 'google', 'bing', 'yandex', 'facebook', 'pinterest', 'twitter', 'email' ) as $k ) {
			$v = sanitize_text_field( $in[ $k ] ?? '' );
			if ( preg_match( '/content=["\']([^"\']+)["\']/', $v, $mm ) ) {
				$v = $mm[1]; // Whole <meta> tag pasted: keep only the code.
			}
			$out[ $k ] = $v;
		}
		$out['same_as']  = implode( "\n", array_filter( array_map( 'esc_url_raw', preg_split( '/[\r\n]+/', (string) ( $in['same_as'] ?? '' ) ) ) ) );
		$out['indexnow'] = isset( $in['indexnow'] ) ? 'on' : 'off';
		update_option( self::OPT, $out );
		wp_safe_redirect( admin_url( 'options-general.php?page=sw-seo&saved=1' ) );
		exit;
	}
}

Scholarwise_SEO::init();
