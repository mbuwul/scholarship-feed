<?php
/**
 * Plugin Name: Scholarship Scout Importer
 * Description: Imports new opportunities and open admissions from the Scholarship Scout feed every hour as drafts. Review, edit and publish them; only published items appear on your site via the [scholarship_scout] shortcode.
 * Version: 1.2.3
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * License: GPL-2.0-or-later
 * Text Domain: scholarship-scout
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Scholarship_Scout_Importer {

	const OPTION   = 'ss_importer_settings';
	const STATUS   = 'ss_importer_status';
	const IGNORED  = 'ss_importer_ignored';
	const CRON     = 'ss_importer_hourly';
	const DEFAULT_FEED = 'https://raw.githubusercontent.com/mbuwul/scholarship-feed/gh-pages/';
	const MAX_PER_RUN  = 150; // Keeps each run short on shared hosting; the rest arrive next hour.

	/** Post types and the feed file each one reads. */
	public static function kinds() {
		return array(
			'ss_opportunity' => array(
				'file'     => 'opportunities.json',
				'list_key' => 'opportunities',
				'singular' => __( 'Opportunity', 'scholarship-scout' ),
				'plural'   => __( 'Opportunities', 'scholarship-scout' ),
				'slug'     => 'opportunities',
				'icon'     => 'dashicons-awards',
			),
			'ss_admission' => array(
				'file'     => 'admissions.json',
				'list_key' => 'admissions',
				'singular' => __( 'Open admission', 'scholarship-scout' ),
				'plural'   => __( 'Open admissions', 'scholarship-scout' ),
				'slug'     => 'admissions',
				'icon'     => 'dashicons-welcome-learn-more',
			),
		);
	}

	/** Editable fields shown in the editor meta box: key => [label, type]. */
	public static function fields( $post_type ) {
		$common = array(
			'deadline'   => array( __( 'Deadline (YYYY-MM-DD, or "rolling")', 'scholarship-scout' ), 'text' ),
			'region'     => array( __( 'Region', 'scholarship-scout' ), 'text' ),
			'levels'     => array( __( 'Levels (comma separated)', 'scholarship-scout' ), 'text' ),
			'fields'     => array( __( 'Fields of study (comma separated)', 'scholarship-scout' ), 'text' ),
			'url'        => array( __( 'Official page / apply link', 'scholarship-scout' ), 'url' ),
		);
		if ( 'ss_admission' === $post_type ) {
			return array(
				'university'      => array( __( 'University', 'scholarship-scout' ), 'text' ),
				'program_country' => array( __( 'Country', 'scholarship-scout' ), 'text' ),
				'city'            => array( __( 'City', 'scholarship-scout' ), 'text' ),
			) + $common + array(
				'apply_url'       => array( __( 'Application portal', 'scholarship-scout' ), 'url' ),
				'intake'          => array( __( 'Intake', 'scholarship-scout' ), 'text' ),
				'languages'       => array( __( 'Languages (comma separated)', 'scholarship-scout' ), 'text' ),
				'tuition'         => array( __( 'Tuition', 'scholarship-scout' ), 'text' ),
				'application_fee' => array( __( 'Application fee', 'scholarship-scout' ), 'text' ),
				'duration'        => array( __( 'Duration', 'scholarship-scout' ), 'text' ),
				'financial_aid'   => array( __( 'Financial aid', 'scholarship-scout' ), 'textarea' ),
			);
		}
		return array(
			'provider'               => array( __( 'Provider', 'scholarship-scout' ), 'text' ),
			'type'                   => array( __( 'Category (scholarship, fellowship, internship, conference, call_for_papers, grant)', 'scholarship-scout' ), 'text' ),
			'host_country'           => array( __( 'Host country', 'scholarship-scout' ), 'text' ),
		) + $common + array(
			'funding'                => array( __( 'Funding (full / partial)', 'scholarship-scout' ), 'text' ),
			'eligible_nationalities' => array( __( 'Eligible nationalities', 'scholarship-scout' ), 'text' ),
		);
	}

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_types' ) );
		add_action( self::CRON, array( __CLASS__, 'run_import' ) );
		add_action( 'admin_menu', array( __CLASS__, 'admin_menu' ) );
		add_action( 'admin_post_ss_import_now', array( __CLASS__, 'handle_import_now' ) );
		add_action( 'admin_post_ss_save_settings', array( __CLASS__, 'handle_save_settings' ) );
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_meta_boxes' ) );
		add_action( 'save_post', array( __CLASS__, 'save_meta' ), 10, 2 );
		add_action( 'before_delete_post', array( __CLASS__, 'remember_deleted' ) );
		add_action( 'transition_post_status', array( __CLASS__, 'cover_on_publish' ), 10, 3 );
		add_shortcode( 'scholarship_scout', array( __CLASS__, 'shortcode' ) );
		add_shortcode( 'scholarship_scout_eligibility', array( __CLASS__, 'eligibility_shortcode' ) );
		foreach ( array_keys( self::kinds() ) as $pt ) {
			add_filter( "manage_{$pt}_posts_columns", array( __CLASS__, 'columns' ) );
			add_action( "manage_{$pt}_posts_custom_column", array( __CLASS__, 'column_value' ), 10, 2 );
		}
		add_filter( 'the_content', array( __CLASS__, 'single_details' ) );
		add_action( 'rest_api_init', array( __CLASS__, 'register_rest' ) );
		add_filter( 'rest_pre_dispatch', array( __CLASS__, 'guard_core_rest' ), 10, 3 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'copy_protection' ) );
		add_action( 'template_redirect', array( __CLASS__, 'block_feeds' ) );
		add_filter( 'http_request_args', array( __CLASS__, 'github_auth' ), 10, 2 );
		add_action( 'after_setup_theme', function () { add_theme_support( 'post-thumbnails' ); add_image_size( 'ss-card', 600, 315, true ); }, 20 );
		// Opening Dashboard > Updates always reads the latest release list.
		add_action( 'load-update-core.php', function () { delete_transient( 'ss_manifest' ); }, 0 );
		add_filter( 'pre_set_site_transient_update_plugins', array( __CLASS__, 'offer_plugin_update' ) );
		add_filter( 'pre_set_site_transient_update_themes', array( __CLASS__, 'offer_theme_update' ) );
		add_action( 'save_post', array( __CLASS__, 'flush_cache' ) );
		add_action( 'deleted_post', array( __CLASS__, 'flush_cache' ) );
	}

	/* ---------- Setup ---------- */

	public static function register_types() {
		foreach ( self::kinds() as $pt => $k ) {
			register_post_type( $pt, array(
				'labels'       => array(
					'name'          => $k['plural'],
					'singular_name' => $k['singular'],
					'menu_name'     => $k['plural'],
					'add_new_item'  => sprintf( __( 'Add %s', 'scholarship-scout' ), $k['singular'] ),
					'edit_item'     => sprintf( __( 'Edit %s', 'scholarship-scout' ), $k['singular'] ),
				),
				'public'       => true,
				'has_archive'  => $k['slug'],
				'rewrite'      => array( 'slug' => $k['slug'] ),
				'menu_icon'    => $k['icon'],
				'supports'     => array( 'title', 'editor', 'revisions', 'thumbnail', 'excerpt' ),
				'show_in_rest' => true,
			) );
		}
	}

	public static function activate() {
		self::register_types();
		flush_rewrite_rules();
		if ( ! wp_next_scheduled( self::CRON ) ) {
			wp_schedule_event( time() + 60, 'hourly', self::CRON );
		}
	}

	public static function deactivate() {
		wp_clear_scheduled_hook( self::CRON );
		flush_rewrite_rules();
	}

	public static function settings() {
		return wp_parse_args( get_option( self::OPTION, array() ), array(
			'feed_base' => self::DEFAULT_FEED,
			'auto'      => 1,
			'protect'   => 1,
			'token'     => '',
		) );
	}

	/* ---------- Import ---------- */

	public static function run_import( $manual = false ) {
		$s = self::settings();
		if ( ! $manual && empty( $s['auto'] ) ) {
			return;
		}
		$base    = trailingslashit( $s['feed_base'] );
		$ignored = get_option( self::IGNORED, array() );
		$report  = array( 'time' => time(), 'created' => 0, 'updated' => 0, 'skipped' => 0, 'more' => 0, 'errors' => array() );

		foreach ( self::kinds() as $pt => $k ) {
			$res = wp_remote_get( $base . $k['file'] . '?t=' . time(), array( 'timeout' => 30 ) );
			if ( is_wp_error( $res ) || 200 !== wp_remote_retrieve_response_code( $res ) ) {
				$report['errors'][] = $k['file'] . ': ' . ( is_wp_error( $res ) ? $res->get_error_message() : 'HTTP ' . wp_remote_retrieve_response_code( $res ) );
				continue;
			}
			$data = json_decode( wp_remote_retrieve_body( $res ), true );
			if ( ! is_array( $data ) || ! isset( $data[ $k['list_key'] ] ) || ! is_array( $data[ $k['list_key'] ] ) ) {
				$report['errors'][] = $k['file'] . ': unreadable feed';
				continue;
			}
			$made    = 0;
			$updated = 0;
			foreach ( $data[ $k['list_key'] ] as $item ) {
				$id = isset( $item['id'] ) ? sanitize_title( $item['id'] ) : '';
				if ( '' === $id || isset( $ignored[ $id ] ) ) {
					$report['skipped']++;
					continue; // Items you deleted permanently are never re-created.
				}
				$existing = self::find_post( $pt, $id );
				if ( $existing ) {
					if ( $updated < self::MAX_PER_RUN && self::refresh_post( $existing, $pt, $item ) ) {
						$updated++;
						$report['updated']++;
					} else {
						$report['skipped']++;
					}
					continue;
				}
				if ( $made >= self::MAX_PER_RUN ) {
					$report['more'] = 1;
					break;
				}
				if ( self::create_draft( $pt, $id, $item ) ) {
					$made++;
					$report['created']++;
				}
			}
		}
		$report['covers'] = self::backfill_covers( 60 );
		$design = self::sync_app();
		if ( $design ) {
			$report['design'] = $design;
		}
		update_option( self::STATUS, $report, false );
		return $report;
	}

	public static function find_post( $pt, $id ) {
		$q = get_posts( array(
			'post_type'      => $pt,
			'post_status'    => 'any',
			'meta_key'       => '_ss_id',
			'meta_value'     => $id,
			'fields'         => 'ids',
			'posts_per_page' => 1,
			'no_found_rows'  => true,
		) );
		return $q ? (int) $q[0] : 0;
	}

	private static function create_draft( $pt, $id, $item ) {
		$body    = self::build_content( $pt, $item );
		$post_id = wp_insert_post( array(
			'post_type'    => $pt,
			'post_status'  => 'draft',
			'post_title'   => wp_strip_all_tags( $item['title'] ?? $id ),
			'post_content' => $body,
		), true );
		if ( is_wp_error( $post_id ) ) {
			return false;
		}
		update_post_meta( $post_id, '_ss_id', $id );
		self::store_item( $post_id, $pt, $item, null );
		update_post_meta( $post_id, '_ss_gen_hash', md5( get_post_field( 'post_content', $post_id, 'raw' ) ) );
		self::make_cover( $post_id );
		return true;
	}

	/** Field value as stored in post meta. */
	private static function flat( $v ) {
		if ( is_array( $v ) ) {
			$v = implode( ', ', array_map( function ( $x ) { return is_scalar( $x ) ? $x : wp_json_encode( $x ); }, $v ) );
		}
		return sanitize_textarea_field( (string) $v );
	}

	/** Saves the feed item's fields. With $old (the previous feed item), only fields you have not edited are changed. */
	private static function store_item( $post_id, $pt, $item, $old ) {
		update_post_meta( $post_id, '_ss_verified_by_source', ! empty( $item['verified'] ) ? 1 : 0 );
		update_post_meta( $post_id, '_ss_raw', wp_slash( wp_json_encode( $item ) ) );
		update_post_meta( $post_id, '_ss_full', self::is_full( $pt, $item ) ? 1 : 0 );
		foreach ( self::fields( $pt ) as $key => $def ) {
			if ( ! isset( $item[ $key ] ) ) {
				continue;
			}
			$new = self::flat( $item[ $key ] );
			if ( null !== $old ) {
				$cur  = (string) get_post_meta( $post_id, 'ss_' . $key, true );
				$prev = isset( $old[ $key ] ) ? self::flat( $old[ $key ] ) : '';
				if ( $cur !== $prev && '' !== $cur ) {
					continue; // You changed this field: keep your version.
				}
			}
			update_post_meta( $post_id, 'ss_' . $key, $new );
		}
	}

	/** True when the item carries the detailed write-up, not just a one-line summary. */
	/** Sites that list opportunities but are not the organisers. Their links are never shown as the official page. */
	const LISTING_SITES = array( 'scholarshipsforafricans.com', 'scholar.africa', 'opportunitiesforafricans.com', 'scholarshipsads.com', 'heysuccess.com', 'opportunitydesk.org', 'scholarshipset.com', 'scholarshipbob.com', 'afterschoolafrica.com', 'scholars4dev.com', 'scholarshipspace.org', 'fundsforngos.org', 'youthop.com', 'opportunitiesforyouth.org', 'wikicfp.com', 'scholarshipregion.com', 'scholarshipportal.com', 'mastersportal.com', 'studyportals.com', 'scholarshiproar.com', 'scholarshipscorner.website', 'scholarshipunion.com', 'worldscholarshipforum.com', 'greatyop.com', 'opportunitiescorners.com', 'opportunitiescorners.info', 'msmeworld.com', 'afterschoolafrica.org' );

	/** True when the link points to a listing site rather than the organiser's own page. */
	public static function is_listing( $url ) {
		$h = strtolower( preg_replace( '/^www\./', '', (string) wp_parse_url( (string) $url, PHP_URL_HOST ) ) );
		if ( '' === $h ) {
			return false;
		}
		foreach ( (array) apply_filters( 'ss_listing_sites', self::LISTING_SITES ) as $d ) {
			if ( $h === $d || substr( $h, -strlen( '.' . $d ) ) === '.' . $d ) {
				return true;
			}
		}
		return false;
	}

	public static function is_full( $pt, $item ) {
		if ( 'ss_admission' === $pt ) {
			return ! empty( $item['description'] ) && ! empty( $item['requirements'] );
		}
		return ! empty( $item['description'] ) && ( ! empty( $item['benefits'] ) || ! empty( $item['requirements'] ) || ! empty( $item['how_to_apply'] ) );
	}

	/**
	 * Updates an imported post when the feed has newer information (for example the full write-up),
	 * but only the parts you have not edited yourself. Status (draft/published) is never changed.
	 */
	private static function refresh_post( $post_id, $pt, $item ) {
		$old_raw = json_decode( (string) get_post_meta( $post_id, '_ss_raw', true ), true );
		if ( ! is_array( $old_raw ) ) {
			$old_raw = array();
		}
		$new_json = wp_json_encode( $item );
		if ( wp_json_encode( $old_raw ) === $new_json ) {
			return false;
		}
		$post    = get_post( $post_id );
		$hash    = (string) get_post_meta( $post_id, '_ss_gen_hash', true );
		$current = md5( $post->post_content );
		if ( '' === $hash ) {
			// Imported by version 1.0: untouched if it still holds the original one-line text.
			$legacy = 'ss_admission' === $pt ? ( $old_raw['description'] ?? '' ) : ( $old_raw['eligibility_summary'] ?? '' );
			$hash   = trim( wp_strip_all_tags( $post->post_content ) ) === trim( wp_strip_all_tags( $legacy ) ) || false !== strpos( $post->post_content, wp_kses_post( $legacy ) . "\n\n<h3>" ) ? $current : 'edited';
		}
		$changed = false;
		if ( $hash === $current ) {
			$body = self::build_content( $pt, $item );
			if ( $body !== $post->post_content ) {
				wp_update_post( array( 'ID' => $post_id, 'post_content' => $body ) );
				update_post_meta( $post_id, '_ss_gen_hash', md5( get_post_field( 'post_content', $post_id, 'raw' ) ) );
				$changed = true;
			}
		}
		self::store_item( $post_id, $pt, $item, $old_raw );
		self::make_cover( $post_id );
		return true;
	}

	private static function as_list( $v ) {
		if ( is_array( $v ) ) {
			return array_values( array_filter( array_map( function ( $x ) {
				if ( is_array( $x ) ) {
					return isset( $x['note'] ) ? (string) $x['note'] : wp_json_encode( $x );
				}
				return trim( (string) $x );
			}, $v ) ) );
		}
		$v = trim( (string) $v );
		if ( '' === $v ) {
			return array();
		}
		$parts = preg_split( '/\R+|(?:^|\s)(?=\d+[\.\)]\s)|;\s+/u', $v );
		$parts = array_values( array_filter( array_map( function ( $x ) { return trim( preg_replace( '/^\s*(?:\d+[\.\)]|[-•*])\s*/u', '', $x ) ); }, $parts ) ) );
		return $parts;
	}

	private static function section( $title, $v, $ordered = false ) {
		$items = self::as_list( $v );
		if ( ! $items ) {
			return '';
		}
		$html = '<h2>' . esc_html( $title ) . '</h2>' . "\n";
		if ( 1 === count( $items ) && ! $ordered ) {
			return $html . '<p>' . esc_html( $items[0] ) . "</p>\n";
		}
		$tag = $ordered ? 'ol' : 'ul';
		return $html . "<$tag>" . implode( '', array_map( function ( $x ) { return '<li>' . esc_html( $x ) . '</li>'; }, $items ) ) . "</$tag>\n";
	}

	/** The post text, written from the feed item in sections. */
	public static function build_content( $pt, $item ) {
		$h = '';
		if ( 'ss_admission' === $pt ) {
			$h .= self::section( __( 'About this programme', 'scholarship-scout' ), $item['description'] ?? '' );
			$h .= self::section( __( 'Programmes you can apply to', 'scholarship-scout' ), $item['degree_names'] ?? array() );
			$h .= self::section( __( 'Entry requirements', 'scholarship-scout' ), $item['requirements'] ?? array() );
			$fees = array_filter( array(
				! empty( $item['tuition'] ) ? sprintf( __( 'Tuition for international students: %s', 'scholarship-scout' ), $item['tuition'] ) : '',
				! empty( $item['application_fee'] ) ? sprintf( __( 'Application fee: %s', 'scholarship-scout' ), $item['application_fee'] ) : '',
			) );
			$h .= self::section( __( 'Tuition and fees', 'scholarship-scout' ), $fees );
			$h .= self::section( __( 'Scholarships and financial aid', 'scholarship-scout' ), $item['financial_aid'] ?? '' );
			$h .= self::section( __( 'Notes for applicants from some countries', 'scholarship-scout' ), $item['origin_notes'] ?? array() );
			$h .= self::section( __( 'Important dates', 'scholarship-scout' ), $item['deadline_note'] ?? '' );
			$h .= self::section( __( 'How to apply', 'scholarship-scout' ), $item['how_to_apply'] ?? '', true );
		} else {
			$about = ! empty( $item['description'] ) ? $item['description'] : ( $item['eligibility_summary'] ?? '' );
			$h .= self::section( __( 'About this opportunity', 'scholarship-scout' ), $about );
			$h .= self::section( __( 'What it covers', 'scholarship-scout' ), $item['benefits'] ?? '' );
			$who = $item['requirements'] ?? array();
			if ( ! $who && ! empty( $item['description'] ) && ! empty( $item['eligibility_summary'] ) ) {
				$who = $item['eligibility_summary'];
			}
			$h .= self::section( __( 'Who can apply', 'scholarship-scout' ), $who );
			$h .= self::section( __( 'Documents you will need', 'scholarship-scout' ), $item['documents'] ?? array() );
			$h .= self::section( __( 'How to apply', 'scholarship-scout' ), $item['how_to_apply'] ?? '', true );
			$h .= self::section( __( 'Good to know', 'scholarship-scout' ), $item['notes'] ?? '' );
		}
		return wp_kses_post( $h );
	}

	public static function remember_deleted( $post_id ) {
		$p = get_post( $post_id );
		if ( ! $p || ! isset( self::kinds()[ $p->post_type ] ) ) {
			return;
		}
		$id = get_post_meta( $post_id, '_ss_id', true );
		if ( $id ) {
			$ignored        = get_option( self::IGNORED, array() );
			$ignored[ $id ] = time();
			update_option( self::IGNORED, $ignored, false );
		}
	}

	/* ---------- Admin ---------- */

	public static function admin_menu() {
		add_submenu_page( 'edit.php?post_type=ss_opportunity', __( 'Feed settings', 'scholarship-scout' ), __( 'Feed settings', 'scholarship-scout' ), 'manage_options', 'ss-feed', array( __CLASS__, 'settings_page' ) );
	}

	public static function settings_page() {
		$s      = self::settings();
		$st     = get_option( self::STATUS );
		$drafts = 0;
		foreach ( array_keys( self::kinds() ) as $pt ) {
			$drafts += (int) wp_count_posts( $pt )->draft;
		}
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Scholarship Scout feed', 'scholarship-scout' ); ?></h1>
			<?php if ( isset( $_GET['ss_msg'] ) ) : ?>
				<div class="notice notice-success"><p><?php echo esc_html( sanitize_text_field( wp_unslash( $_GET['ss_msg'] ) ) ); ?></p></div>
			<?php endif; ?>
			<p><?php esc_html_e( 'New items arrive as drafts. Open a draft, check and edit it, then press Publish. Only published items appear on your site. Items you have edited are never overwritten, and items you delete permanently are not imported again.', 'scholarship-scout' ); ?></p>
			<p>
				<a class="button button-primary" href="<?php echo esc_url( admin_url( 'edit.php?post_status=draft&post_type=ss_opportunity' ) ); ?>"><?php esc_html_e( 'Review opportunity drafts', 'scholarship-scout' ); ?></a>
				<a class="button" href="<?php echo esc_url( admin_url( 'edit.php?post_status=draft&post_type=ss_admission' ) ); ?>"><?php esc_html_e( 'Review admission drafts', 'scholarship-scout' ); ?></a>
				&nbsp; <?php echo esc_html( sprintf( _n( '%d draft waiting', '%d drafts waiting', $drafts, 'scholarship-scout' ), $drafts ) ); ?>
			</p>
			<h2><?php esc_html_e( 'Last import', 'scholarship-scout' ); ?></h2>
			<p>
			<?php
			if ( $st ) {
				echo esc_html( sprintf( __( '%1$s: %2$d new drafts, %3$d updated with newer information, %4$d unchanged.', 'scholarship-scout' ), wp_date( 'j M Y H:i', $st['time'] ), $st['created'], $st['updated'] ?? 0, $st['skipped'] ) );
				echo '<br>' . esc_html( sprintf( __( 'Website design version: %s', 'scholarship-scout' ), get_option( 'ss_app_version', 'built-in' ) ) );
				if ( ! empty( $st['more'] ) ) {
					echo '<br>' . esc_html__( 'More new items are waiting and will arrive on the next check.', 'scholarship-scout' );
				}
				foreach ( $st['errors'] as $e ) {
					echo '<br><strong>' . esc_html__( 'Problem:', 'scholarship-scout' ) . '</strong> ' . esc_html( $e );
				}
			} else {
				esc_html_e( 'No import has run yet.', 'scholarship-scout' );
			}
			$next = wp_next_scheduled( self::CRON );
			if ( $next && ! empty( $s['auto'] ) ) {
				echo '<br>' . esc_html( sprintf( __( 'Next automatic check: %s', 'scholarship-scout' ), wp_date( 'j M Y H:i', $next ) ) );
			}
			?>
			</p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'ss_import_now' ); ?>
				<input type="hidden" name="action" value="ss_import_now">
				<?php submit_button( __( 'Check for new items now', 'scholarship-scout' ), 'secondary', 'submit', false ); ?>
			</form>
			<h2><?php esc_html_e( 'Settings', 'scholarship-scout' ); ?></h2>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'ss_save_settings' ); ?>
				<input type="hidden" name="action" value="ss_save_settings">
				<table class="form-table">
					<tr><th><label for="ss_feed_base"><?php esc_html_e( 'Feed address', 'scholarship-scout' ); ?></label></th>
						<td><input type="url" class="regular-text" id="ss_feed_base" name="feed_base" value="<?php echo esc_attr( $s['feed_base'] ); ?>">
						<p class="description"><?php esc_html_e( 'The folder that holds opportunities.json and admissions.json.', 'scholarship-scout' ); ?></p></td></tr>
					<tr><th><?php esc_html_e( 'Automatic import', 'scholarship-scout' ); ?></th>
						<td><label><input type="checkbox" name="auto" value="1" <?php checked( ! empty( $s['auto'] ) ); ?>> <?php esc_html_e( 'Check the feed every hour', 'scholarship-scout' ); ?></label></td></tr>
					<tr><th><?php esc_html_e( 'Copy protection', 'scholarship-scout' ); ?></th>
						<td><label><input type="checkbox" name="protect" value="1" <?php checked( ! empty( $s['protect'] ) ); ?>> <?php esc_html_e( 'Stop visitors from selecting, copying or right-clicking content (you are not affected while logged in)', 'scholarship-scout' ); ?></label></td></tr>
					<tr><th><label for="ss_token"><?php esc_html_e( 'GitHub access token', 'scholarship-scout' ); ?></label></th>
						<td><input type="password" class="regular-text" id="ss_token" name="token" value="" placeholder="<?php echo esc_attr( $s['token'] ? __( 'Saved (leave empty to keep)', 'scholarship-scout' ) : __( 'Only needed if your feed repository is private', 'scholarship-scout' ) ); ?>" autocomplete="off"></td></tr>
				</table>
				<?php submit_button(); ?>
			</form>
			<h2><?php esc_html_e( 'Show the list on your site', 'scholarship-scout' ); ?></h2>
			<p><?php esc_html_e( 'Add one of these shortcodes to any page (in the block editor use a Shortcode block):', 'scholarship-scout' ); ?></p>
			<p><code>[scholarship_scout]</code> &nbsp; <code>[scholarship_scout show="admissions"]</code></p>
		</div>
		<?php
	}

	public static function handle_import_now() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed' );
		}
		check_admin_referer( 'ss_import_now' );
		$r   = self::run_import( true );
		$msg = sprintf( __( 'Import finished: %1$d new drafts, %2$d updated.', 'scholarship-scout' ), $r['created'], $r['updated'] ) . ( $r['errors'] ? ' ' . implode( '; ', $r['errors'] ) : '' );
		wp_safe_redirect( add_query_arg( 'ss_msg', rawurlencode( $msg ), admin_url( 'edit.php?post_type=ss_opportunity&page=ss-feed' ) ) );
		exit;
	}

	public static function handle_save_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed' );
		}
		check_admin_referer( 'ss_save_settings' );
		update_option( self::OPTION, array(
			'feed_base' => esc_url_raw( wp_unslash( $_POST['feed_base'] ?? self::DEFAULT_FEED ) ),
			'auto'      => empty( $_POST['auto'] ) ? 0 : 1,
			'protect'   => empty( $_POST['protect'] ) ? 0 : 1,
			'token'     => isset( $_POST['token'] ) && '' !== trim( wp_unslash( $_POST['token'] ) ) ? sanitize_text_field( wp_unslash( $_POST['token'] ) ) : self::settings()['token'],
		) );
		delete_transient( 'ss_manifest' );
		wp_safe_redirect( add_query_arg( 'ss_msg', rawurlencode( __( 'Settings saved.', 'scholarship-scout' ) ), admin_url( 'edit.php?post_type=ss_opportunity&page=ss-feed' ) ) );
		exit;
	}

	public static function add_meta_boxes() {
		foreach ( array_keys( self::kinds() ) as $pt ) {
			add_meta_box( 'ss_details', __( 'Details (check before publishing)', 'scholarship-scout' ), array( __CLASS__, 'meta_box' ), $pt, 'normal', 'high' );
		}
	}

	public static function meta_box( $post ) {
		wp_nonce_field( 'ss_meta', 'ss_meta_nonce' );
		$src = get_post_meta( $post->ID, '_ss_verified_by_source', true );
		if ( get_post_meta( $post->ID, '_ss_id', true ) ) {
			echo '<p><em>' . ( $src ? esc_html__( 'Imported from the feed. The research step checked this against the official page.', 'scholarship-scout' ) : esc_html__( 'Imported from the feed. Not yet checked against the official page: please verify the deadline and eligibility.', 'scholarship-scout' ) ) . '</em></p>';
		}
		if ( self::is_listing( get_post_meta( $post->ID, 'ss_url', true ) ) ) {
			echo '<p style="color:#b42318"><strong>' . esc_html__( 'No official link yet.', 'scholarship-scout' ) . '</strong> ' . esc_html__( 'The link below goes to a listing site, not the organiser. The official page is being looked up and will replace it automatically. Until then, the article shows no official-site button. You can paste the official link yourself.', 'scholarship-scout' ) . '</p>';
		}
		if ( get_post_meta( $post->ID, '_ss_id', true ) && ! get_post_meta( $post->ID, '_ss_full', true ) ) {
			echo '<p style="color:#b54708"><strong>' . esc_html__( 'Short write-up.', 'scholarship-scout' ) . '</strong> ' . esc_html__( 'The full details (about, what it covers, who can apply, how to apply) are being researched and will be filled in automatically, as long as you have not edited the text yourself.', 'scholarship-scout' ) . '</p>';
		}
		echo '<table class="form-table">';
		foreach ( self::fields( $post->post_type ) as $key => $def ) {
			$v  = get_post_meta( $post->ID, 'ss_' . $key, true );
			$id = 'ss_f_' . $key;
			echo '<tr><th><label for="' . esc_attr( $id ) . '">' . esc_html( $def[0] ) . '</label></th><td>';
			if ( 'textarea' === $def[1] ) {
				echo '<textarea class="large-text" rows="3" id="' . esc_attr( $id ) . '" name="ss[' . esc_attr( $key ) . ']">' . esc_textarea( $v ) . '</textarea>';
			} else {
				echo '<input class="large-text" type="' . ( 'url' === $def[1] ? 'url' : 'text' ) . '" id="' . esc_attr( $id ) . '" name="ss[' . esc_attr( $key ) . ']" value="' . esc_attr( $v ) . '">';
			}
			if ( 'url' === $def[1] && $v ) {
				echo ' <a href="' . esc_url( $v ) . '" target="_blank" rel="noopener">' . esc_html__( 'Open', 'scholarship-scout' ) . '</a>';
			}
			echo '</td></tr>';
		}
		echo '</table>';
	}

	public static function save_meta( $post_id, $post ) {
		if ( ! isset( self::kinds()[ $post->post_type ] ) || ! isset( $_POST['ss_meta_nonce'] ) ) {
			return;
		}
		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ss_meta_nonce'] ) ), 'ss_meta' ) || ! current_user_can( 'edit_post', $post_id ) || wp_is_post_autosave( $post_id ) ) {
			return;
		}
		$in = isset( $_POST['ss'] ) && is_array( $_POST['ss'] ) ? wp_unslash( $_POST['ss'] ) : array();
		foreach ( self::fields( $post->post_type ) as $key => $def ) {
			if ( ! isset( $in[ $key ] ) ) {
				continue;
			}
			$v = 'url' === $def[1] ? esc_url_raw( $in[ $key ] ) : sanitize_textarea_field( $in[ $key ] );
			update_post_meta( $post_id, 'ss_' . $key, $v );
		}
	}

	public static function columns( $cols ) {
		$new = array();
		foreach ( $cols as $k => $v ) {
			$new[ $k ] = $v;
			if ( 'title' === $k ) {
				$new['ss_deadline'] = __( 'Deadline', 'scholarship-scout' );
				$new['ss_where']    = __( 'Country', 'scholarship-scout' );
				$new['ss_link']     = __( 'Official page', 'scholarship-scout' );
				$new['ss_full']     = __( 'Write-up', 'scholarship-scout' );
			}
		}
		return $new;
	}

	public static function column_value( $col, $post_id ) {
		if ( 'ss_deadline' === $col ) {
			echo esc_html( get_post_meta( $post_id, 'ss_deadline', true ) );
		} elseif ( 'ss_where' === $col ) {
			echo esc_html( get_post_meta( $post_id, 'ss_host_country', true ) ?: get_post_meta( $post_id, 'ss_program_country', true ) );
		} elseif ( 'ss_full' === $col ) {
			echo get_post_meta( $post_id, '_ss_full', true ) ? '<span style="color:#0b6e4f;font-weight:600">' . esc_html__( 'Full details', 'scholarship-scout' ) . '</span>' : '<span style="color:#b54708">' . esc_html__( 'Short: details coming', 'scholarship-scout' ) . '</span>';
		} elseif ( 'ss_link' === $col ) {
			$u = get_post_meta( $post_id, 'ss_url', true );
			if ( $u && self::is_listing( $u ) ) {
				echo '<span style="color:#b42318;font-weight:600">' . esc_html__( 'Listing site, not official', 'scholarship-scout' ) . '</span> <a href="' . esc_url( $u ) . '" target="_blank" rel="noopener">' . esc_html__( 'Open', 'scholarship-scout' ) . '</a>';
			} elseif ( $u ) {
				echo '<a href="' . esc_url( $u ) . '" target="_blank" rel="noopener">' . esc_html__( 'Open', 'scholarship-scout' ) . '</a>';
			}
		}
	}

	/* ---------- Front end ---------- */

	private static $LABELS = null;

	private static function type_label( $t ) {
		if ( null === self::$LABELS ) {
			self::$LABELS = array(
				'scholarship'     => __( 'Scholarship', 'scholarship-scout' ),
				'fellowship'      => __( 'Fellowship', 'scholarship-scout' ),
				'internship'      => __( 'Internship', 'scholarship-scout' ),
				'conference'      => __( 'Funded conference', 'scholarship-scout' ),
				'call_for_papers' => __( 'Call for papers', 'scholarship-scout' ),
				'grant'           => __( 'Grant', 'scholarship-scout' ),
			);
		}
		return self::$LABELS[ $t ] ?? ucfirst( str_replace( '_', ' ', (string) $t ) );
	}

	private static function m( $id, $k ) {
		return (string) get_post_meta( $id, 'ss_' . $k, true );
	}

	/** Builds the single opportunity/admission page: key facts, deadline countdown, write-up, apply button, sharing, similar items. */
	public static function single_details( $content ) {
		if ( ! is_singular( array_keys( self::kinds() ) ) || ! in_the_loop() || ! is_main_query() ) {
			return $content;
		}
		$id  = get_the_ID();
		$pt  = get_post_type( $id );
		$adm = 'ss_admission' === $pt;
		$dl  = self::m( $id, 'deadline' );

		// Deadline banner.
		$banner = '';
		if ( 'rolling' === $dl ) {
			$banner = esc_html__( 'Applications are reviewed on a rolling basis. Apply early.', 'scholarship-scout' );
		} elseif ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $dl ) ) {
			$days   = (int) floor( ( strtotime( $dl . ' 23:59:59' ) - current_time( 'timestamp' ) ) / DAY_IN_SECONDS );
			$date   = wp_date( 'l j F Y', strtotime( $dl . ' 12:00:00' ) );
			$banner = $days < 0 ? sprintf( esc_html__( 'The deadline (%s) has passed.', 'scholarship-scout' ), esc_html( $date ) )
				: ( 0 === $days ? sprintf( esc_html__( 'Deadline: %s. Closes today.', 'scholarship-scout' ), esc_html( $date ) )
				: sprintf( esc_html( _n( 'Deadline: %1$s (%2$d day left)', 'Deadline: %1$s (%2$d days left)', $days, 'scholarship-scout' ) ), esc_html( $date ), $days ) );
		}

		// Key facts.
		$facts = $adm ? array(
			__( 'University', 'scholarship-scout' )   => self::m( $id, 'university' ),
			__( 'Country', 'scholarship-scout' )      => trim( self::m( $id, 'city' ) . ', ' . self::m( $id, 'program_country' ), ', ' ),
			__( 'Level', 'scholarship-scout' )        => self::m( $id, 'levels' ),
			__( 'Intake', 'scholarship-scout' )       => self::m( $id, 'intake' ),
			__( 'Language', 'scholarship-scout' )     => self::m( $id, 'languages' ),
			__( 'Duration', 'scholarship-scout' )     => self::m( $id, 'duration' ),
			__( 'Tuition', 'scholarship-scout' )      => self::m( $id, 'tuition' ),
			__( 'Application fee', 'scholarship-scout' ) => self::m( $id, 'application_fee' ),
		) : array(
			__( 'Type', 'scholarship-scout' )         => self::type_label( self::m( $id, 'type' ) ),
			__( 'Offered by', 'scholarship-scout' )   => self::m( $id, 'provider' ),
			__( 'Host country', 'scholarship-scout' ) => self::m( $id, 'host_country' ),
			__( 'Level', 'scholarship-scout' )        => self::m( $id, 'levels' ),
			__( 'Funding', 'scholarship-scout' )      => 'full' === self::m( $id, 'funding' ) ? __( 'Fully funded', 'scholarship-scout' ) : ( 'partial' === self::m( $id, 'funding' ) ? __( 'Partially funded', 'scholarship-scout' ) : self::m( $id, 'funding' ) ),
			__( 'Fields', 'scholarship-scout' )       => 'any' === strtolower( self::m( $id, 'fields' ) ) ? __( 'All fields', 'scholarship-scout' ) : self::m( $id, 'fields' ),
			__( 'Open to', 'scholarship-scout' )      => 'any' === strtolower( self::m( $id, 'eligible_nationalities' ) ) ? __( 'All nationalities', 'scholarship-scout' ) : self::m( $id, 'eligible_nationalities' ),
		);
		$grid = '';
		foreach ( $facts as $k => $v ) {
			if ( '' !== trim( (string) $v ) ) {
				$grid .= '<div class="ss-fact"><span>' . esc_html( $k ) . '</span><strong>' . esc_html( ucfirst( $v ) ) . '</strong></div>';
			}
		}

		$url  = self::m( $id, 'apply_url' ) ?: self::m( $id, 'url' );
		$off  = self::m( $id, 'url' );
		if ( self::is_listing( $url ) ) {
			$url = ( $off && ! self::is_listing( $off ) ) ? $off : '';
		}
		$host = $off ? preg_replace( '/^www\./', '', (string) wp_parse_url( $off, PHP_URL_HOST ) ) : '';
		$official = $url ? '<div class="ss-official"><h2>' . esc_html__( 'Official website', 'scholarship-scout' ) . '</h2><p>' . esc_html__( 'Read the full call and apply on the official page. Details can change, so always confirm the deadline and requirements there before you apply.', 'scholarship-scout' ) . '</p><a class="ss-apply" href="' . esc_url( $url ) . '" target="_blank" rel="noopener nofollow">' . esc_html( sprintf( __( 'Go to %s', 'scholarship-scout' ), $host ?: __( 'the official page', 'scholarship-scout' ) ) ) . ' &rarr;</a></div>' : '';

		$link  = rawurlencode( get_permalink( $id ) );
		$title = rawurlencode( get_the_title( $id ) );
		$share = '<div class="ss-share"><span>' . esc_html__( 'Share with a friend:', 'scholarship-scout' ) . '</span>'
			. '<a href="https://wa.me/?text=' . $title . '%20' . $link . '" target="_blank" rel="noopener">WhatsApp</a>'
			. '<a href="https://www.facebook.com/sharer/sharer.php?u=' . $link . '" target="_blank" rel="noopener">Facebook</a>'
			. '<a href="https://www.linkedin.com/sharing/share-offsite/?url=' . $link . '" target="_blank" rel="noopener">LinkedIn</a>'
			. '<a href="https://twitter.com/intent/tweet?text=' . $title . '&url=' . $link . '" target="_blank" rel="noopener">X</a>'
			. '<a href="https://t.me/share/url?url=' . $link . '&text=' . $title . '" target="_blank" rel="noopener">Telegram</a></div>';

		// Similar items.
		$args = array( 'post_type' => $pt, 'post_status' => 'publish', 'posts_per_page' => 4, 'post__not_in' => array( $id ), 'no_found_rows' => true,
			'meta_query' => array( array( 'key' => 'ss_deadline', 'value' => current_time( 'Y-m-d' ), 'compare' => '>=' ) ), 'meta_key' => 'ss_deadline', 'orderby' => 'meta_value', 'order' => 'ASC' );
		if ( ! $adm && self::m( $id, 'type' ) ) {
			$args['meta_query'][] = array( 'key' => 'ss_type', 'value' => self::m( $id, 'type' ) );
		}
		$sim = '';
		foreach ( get_posts( $args ) as $p ) {
			$sd   = self::m( $p->ID, 'deadline' );
			$sim .= '<li><a href="' . esc_url( get_permalink( $p ) ) . '">' . esc_html( get_the_title( $p ) ) . '</a>' . ( $sd && 'rolling' !== $sd ? ' <small>' . esc_html( wp_date( 'j M Y', strtotime( $sd . ' 12:00:00' ) ) ) . '</small>' : '' ) . '</li>';
		}
		$sim = $sim ? '<div class="ss-similar"><h2>' . esc_html( $adm ? __( 'More open admissions', 'scholarship-scout' ) : __( 'Similar opportunities', 'scholarship-scout' ) ) . '</h2><ul>' . $sim . '</ul></div>' : '';

		$css = '<style>.ss-single{--ss-line:rgba(127,127,127,.28);--ss-acc:#0b6e4f}.ss-banner{background:rgba(11,110,79,.1);border-left:4px solid var(--ss-acc);padding:12px 14px;border-radius:8px;font-weight:600;margin:0 0 18px}'
			. '.ss-facts{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:10px;margin:0 0 20px}.ss-fact{border:1px solid var(--ss-line);border-radius:10px;padding:10px 12px;display:flex;flex-direction:column;gap:2px}.ss-fact span{font-size:.8em;opacity:.7}.ss-fact strong{font-size:.95em}'
			. '.ss-single h2{font-size:1.2em;margin:26px 0 8px}.ss-single ul,.ss-single ol{padding-left:1.3em}.ss-single li{margin:4px 0}'
			. '.ss-apply-row{margin:24px 0 10px}.ss-apply{display:inline-block;background:var(--ss-acc);color:#fff!important;padding:12px 18px;border-radius:10px;text-decoration:none;font-weight:700}'
			. '.ss-share{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin:14px 0}.ss-share a{border:1px solid var(--ss-line);border-radius:999px;padding:4px 12px;text-decoration:none;font-size:.88em}'
			. '.ss-similar{border-top:1px solid var(--ss-line);margin-top:24px;padding-top:6px}.ss-similar small{opacity:.7}'
			. '.ss-official{margin-top:28px;border:1px solid var(--ss-line);border-radius:12px;padding:18px 18px 20px;background:rgba(127,127,127,.06)}.ss-official h2{margin-top:0}.ss-official p{margin:0 0 14px}</style>';

		return $css . '<div class="ss-single">' . ( $banner ? '<p class="ss-banner">' . $banner . '</p>' : '' ) . '<div class="ss-facts">' . $grid . '</div>' . $content . $share . $sim . $official . '</div>';
	}

	public static function shortcode( $atts ) {
		$a  = shortcode_atts( array( 'show' => 'opportunities', 'per_page' => 30 ), $atts, 'scholarship_scout' );
		$pt = 'admissions' === $a['show'] ? 'ss_admission' : 'ss_opportunity';
		$today = current_time( 'Y-m-d' );
		$posts = get_posts( array( 'post_type' => $pt, 'post_status' => 'publish', 'posts_per_page' => -1, 'no_found_rows' => true ) );
		$items = array();
		foreach ( $posts as $p ) {
			$dl = self::m( $p->ID, 'deadline' );
			if ( $dl && 'rolling' !== $dl && $dl < $today ) {
				continue; // Hide passed deadlines automatically.
			}
			$items[] = array( 'p' => $p, 'dl' => $dl ? $dl : '9999' );
		}
		usort( $items, function ( $x, $y ) { return strcmp( $x['dl'], $y['dl'] ); } );

		$uid     = 'ss' . wp_rand( 1000, 999999 );
		$filters = 'ss_admission' === $pt
			? array( 'country' => __( 'All countries', 'scholarship-scout' ), 'level' => __( 'All levels', 'scholarship-scout' ), 'lang' => __( 'All languages', 'scholarship-scout' ) )
			: array( 'type' => __( 'All categories', 'scholarship-scout' ), 'region' => __( 'All regions', 'scholarship-scout' ), 'country' => __( 'All countries', 'scholarship-scout' ), 'level' => __( 'All levels', 'scholarship-scout' ) );
		$opts    = array_fill_keys( array_keys( $filters ), array() );
		$cards   = '';
		foreach ( $items as $it ) {
			$p       = $it['p'];
			$id      = $p->ID;
			$country = 'ss_admission' === $pt ? self::m( $id, 'program_country' ) : self::m( $id, 'host_country' );
			$levels  = array_filter( array_map( 'trim', explode( ',', self::m( $id, 'levels' ) ) ) );
			$langs   = array_filter( array_map( 'trim', explode( ',', self::m( $id, 'languages' ) ) ) );
			$type    = self::m( $id, 'type' );
			$region  = self::m( $id, 'region' );
			foreach ( array( 'country' => array( $country ), 'level' => $levels, 'lang' => $langs, 'type' => array( $type ), 'region' => array( $region ) ) as $k => $vals ) {
				if ( isset( $opts[ $k ] ) ) {
					foreach ( $vals as $v ) {
						if ( '' !== $v ) {
							$opts[ $k ][ $v ] = 'type' === $k ? self::type_label( $v ) : $v;
						}
					}
				}
			}
			$sub   = 'ss_admission' === $pt ? self::m( $id, 'university' ) : self::m( $id, 'provider' );
			$dl    = self::m( $id, 'deadline' );
			$chips = '<span class="ss-chip ss-dl" data-dl="' . esc_attr( $dl ) . '">' . esc_html( 'rolling' === $dl ? __( 'Rolling deadline', 'scholarship-scout' ) : ( $dl ? sprintf( __( 'Deadline %s', 'scholarship-scout' ), wp_date( 'j M Y', strtotime( $dl . ' 12:00:00' ) ) ) : '' ) ) . '</span>';
			if ( $type ) {
				$chips .= '<span class="ss-chip">' . esc_html( self::type_label( $type ) ) . '</span>';
			}
			if ( ( time() - get_post_time( 'U', true, $p ) ) < 7 * DAY_IN_SECONDS ) {
				$chips = '<span class="ss-chip ss-new">' . esc_html__( 'New', 'scholarship-scout' ) . '</span>' . $chips;
			}
			$fund = self::m( $id, 'funding' );
			if ( $fund ) {
				$chips .= '<span class="ss-chip">' . esc_html( 'full' === $fund ? __( 'Fully funded', 'scholarship-scout' ) : ( 'partial' === $fund ? __( 'Partially funded', 'scholarship-scout' ) : $fund ) ) . '</span>';
			}
			if ( $levels ) {
				$chips .= '<span class="ss-chip">' . esc_html( implode( ', ', $levels ) ) . '</span>';
			}
			$search = strtolower( implode( ' ', array( $p->post_title, $sub, $country, self::m( $id, 'fields' ), wp_strip_all_tags( $p->post_content ) ) ) );
			$cards .= sprintf(
				'<div class="ss-card" data-type="%s" data-region="%s" data-country="%s" data-level="%s" data-lang="%s" data-q="%s"><a class="ss-t" href="%s">%s</a><div class="ss-p">%s</div><div class="ss-s">%s</div><div class="ss-chips">%s</div></div>',
				esc_attr( $type ), esc_attr( $region ), esc_attr( $country ), esc_attr( '|' . implode( '|', $levels ) . '|' ), esc_attr( '|' . implode( '|', $langs ) . '|' ), esc_attr( $search ),
				esc_url( get_permalink( $p ) ), esc_html( get_the_title( $p ) ),
				esc_html( trim( $sub . ( $country ? ' · ' . $country : '' ), ' ·' ) ),
				esc_html( wp_trim_words( wp_strip_all_tags( $p->post_content ), 40 ) ),
				$chips
			);
		}

		$bar = '<input type="search" data-f="q" placeholder="' . esc_attr__( 'Search', 'scholarship-scout' ) . '">';
		foreach ( $filters as $k => $all ) {
			asort( $opts[ $k ] );
			$bar .= '<select data-f="' . esc_attr( $k ) . '"><option value="">' . esc_html( $all ) . '</option>';
			foreach ( $opts[ $k ] as $v => $label ) {
				$bar .= '<option value="' . esc_attr( $v ) . '">' . esc_html( $label ) . '</option>';
			}
			$bar .= '</select>';
		}

		ob_start();
		?>
		<div class="ss-wrap" id="<?php echo esc_attr( $uid ); ?>" data-per="<?php echo (int) $a['per_page']; ?>">
			<style>
			.ss-wrap{--ss-line:rgba(127,127,127,.3);--ss-chip:rgba(127,127,127,.12);--ss-acc:#0b6e4f;--ss-warn:#b54708;--ss-hot:#c4320a}
			.ss-bar{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:14px}.ss-bar input,.ss-bar select{font:inherit;padding:8px 10px;border:1px solid var(--ss-line);border-radius:8px;min-width:0;max-width:100%}.ss-bar input{flex:1 1 220px}
			.ss-card{border:1px solid var(--ss-line);border-radius:10px;padding:12px 14px;margin-bottom:10px}.ss-t{font-weight:600;text-decoration:none}.ss-t:hover{text-decoration:underline}
			.ss-p{opacity:.75;font-size:.9em}.ss-s{margin:6px 0 8px;font-size:.95em}.ss-chips{display:flex;flex-wrap:wrap;gap:6px}.ss-chip{background:var(--ss-chip);border-radius:999px;padding:2px 9px;font-size:.8em}
			.ss-new{background:var(--ss-acc);color:#fff}.ss-soon{color:var(--ss-warn);font-weight:600}.ss-urgent{color:var(--ss-hot);font-weight:600}.ss-more{font:inherit;width:100%;padding:8px;border:1px solid var(--ss-line);border-radius:8px;background:var(--ss-chip);cursor:pointer}.ss-empty{opacity:.7}
			</style>
			<div class="ss-bar"><?php echo $bar; // phpcs:ignore -- escaped above ?></div>
			<div class="ss-list"><?php echo $cards ? $cards : '<p class="ss-empty">' . esc_html__( 'No opportunities published yet.', 'scholarship-scout' ) . '</p>'; // phpcs:ignore -- escaped above ?></div>
			<p class="ss-empty ss-none" hidden><?php esc_html_e( 'Nothing matches these filters.', 'scholarship-scout' ); ?></p>
			<button type="button" class="ss-more" hidden><?php esc_html_e( 'Show more', 'scholarship-scout' ); ?></button>
		</div>
		<script>
		(function(){var w=document.getElementById(<?php echo wp_json_encode( $uid ); ?>);if(!w)return;
		var per=+w.getAttribute('data-per')||30,shown=per,cards=[].slice.call(w.querySelectorAll('.ss-card')),f=[].slice.call(w.querySelectorAll('[data-f]'));
		var now=Date.now();cards.forEach(function(c){var d=c.querySelector('.ss-dl'),v=d&&d.getAttribute('data-dl');if(!v||v==='rolling')return;var n=Math.round((new Date(v+'T23:59:59')-now)/864e5);
		if(n<=7){d.classList.add(n<=1?'ss-urgent':'ss-soon');d.textContent=n<=0?<?php echo wp_json_encode( __( 'Closes today', 'scholarship-scout' ) ); ?>:n===1?<?php echo wp_json_encode( __( 'Closes tomorrow', 'scholarship-scout' ) ); ?>:n+<?php echo wp_json_encode( __( ' days left', 'scholarship-scout' ) ); ?>;}});
		function run(){var v={};f.forEach(function(e){v[e.getAttribute('data-f')]=e.value.toLowerCase().trim();});var m=0;
		cards.forEach(function(c){var ok=(!v.q||c.getAttribute('data-q').indexOf(v.q)>=0)&&['type','region','country'].every(function(k){return !v[k]||(c.getAttribute('data-'+k)||'').toLowerCase()===v[k];})&&['level','lang'].every(function(k){return !v[k]||(c.getAttribute('data-'+k)||'').toLowerCase().indexOf('|'+v[k]+'|')>=0;});
		c.style.display=ok&&m<shown?'':'none';if(ok)m++;});w.querySelector('.ss-more').hidden=m<=shown;w.querySelector('.ss-none').hidden=m>0||!cards.length;}
		try{var u=new URLSearchParams(location.search);f.forEach(function(e){var k=e.getAttribute('data-f'),v=u.get(k);if(v){if(e.tagName==='SELECT'){[].forEach.call(e.options,function(o){if(o.value.toLowerCase()===v.toLowerCase())e.value=o.value;});}else{e.value=v;}}});}catch(x){}
		f.forEach(function(e){e.addEventListener('input',function(){shown=per;run();});});w.querySelector('.ss-more').addEventListener('click',function(){shown+=per;run();});run();})();
		</script>
		<?php
		return ob_get_clean();
	}

	/** Eligibility checker: visitor fills a short form, gets the published opportunities that fit them. */
	public static function eligibility_shortcode() {
		$today = current_time( 'Y-m-d' );
		$rows  = array();
		foreach ( get_posts( array( 'post_type' => 'ss_opportunity', 'post_status' => 'publish', 'posts_per_page' => -1, 'no_found_rows' => true ) ) as $p ) {
			$dl = self::m( $p->ID, 'deadline' );
			if ( $dl && 'rolling' !== $dl && $dl < $today ) {
				continue;
			}
			$rows[] = array(
				't'  => get_the_title( $p ),
				'u'  => get_permalink( $p ),
				'pr' => self::m( $p->ID, 'provider' ),
				'c'  => self::m( $p->ID, 'host_country' ),
				'r'  => self::m( $p->ID, 'region' ),
				'ty' => self::m( $p->ID, 'type' ),
				'tl' => self::type_label( self::m( $p->ID, 'type' ) ),
				'l'  => strtolower( self::m( $p->ID, 'levels' ) ),
				'f'  => strtolower( self::m( $p->ID, 'fields' ) ),
				'n'  => strtolower( self::m( $p->ID, 'eligible_nationalities' ) ),
				'fu' => self::m( $p->ID, 'funding' ),
				'd'  => $dl,
			);
		}
		usort( $rows, function ( $a, $b ) { return strcmp( $a['d'] ?: '9999', $b['d'] ?: '9999' ); } );
		$countries = array( 'Algeria','Angola','Benin','Botswana','Burkina Faso','Burundi','Cabo Verde','Cameroon','Central African Republic','Chad','Comoros','Congo (Brazzaville)','Congo (DRC)',"Cote d'Ivoire",'Djibouti','Egypt','Equatorial Guinea','Eritrea','Eswatini','Ethiopia','Gabon','Gambia','Ghana','Guinea','Guinea-Bissau','Kenya','Lesotho','Liberia','Libya','Madagascar','Malawi','Mali','Mauritania','Mauritius','Morocco','Mozambique','Namibia','Niger','Nigeria','Rwanda','Sao Tome and Principe','Senegal','Seychelles','Sierra Leone','Somalia','South Africa','South Sudan','Sudan','Tanzania','Togo','Tunisia','Uganda','Zambia','Zimbabwe' );
		$uid = 'sse' . wp_rand( 1000, 999999 );
		ob_start();
		?>
		<div class="ss-elig" id="<?php echo esc_attr( $uid ); ?>">
			<form class="ss-elig-form">
				<label><?php esc_html_e( 'Your nationality', 'scholarship-scout' ); ?>
					<select name="nat" required><option value=""><?php esc_html_e( 'Choose a country', 'scholarship-scout' ); ?></option>
					<?php foreach ( $countries as $c ) : ?><option><?php echo esc_html( $c ); ?></option><?php endforeach; ?>
					</select></label>
				<label><?php esc_html_e( 'Level you want to study or work at', 'scholarship-scout' ); ?>
					<select name="lvl"><option value=""><?php esc_html_e( 'Any level', 'scholarship-scout' ); ?></option>
						<option value="undergraduate"><?php esc_html_e( "Bachelor's / undergraduate", 'scholarship-scout' ); ?></option>
						<option value="masters"><?php esc_html_e( "Master's", 'scholarship-scout' ); ?></option>
						<option value="phd"><?php esc_html_e( 'PhD', 'scholarship-scout' ); ?></option>
						<option value="postdoc"><?php esc_html_e( 'Postdoc', 'scholarship-scout' ); ?></option>
						<option value="professional"><?php esc_html_e( 'Professional / early career', 'scholarship-scout' ); ?></option>
					</select></label>
				<label><?php esc_html_e( 'Field of study (optional)', 'scholarship-scout' ); ?>
					<input name="fld" type="text" placeholder="<?php esc_attr_e( 'e.g. public health, engineering, law', 'scholarship-scout' ); ?>"></label>
				<label><?php esc_html_e( 'Where you want to go', 'scholarship-scout' ); ?>
					<select name="reg"><option value=""><?php esc_html_e( 'Anywhere', 'scholarship-scout' ); ?></option><option>Europe</option><option>Asia</option><option>North America</option></select></label>
				<label><?php esc_html_e( 'Funding', 'scholarship-scout' ); ?>
					<select name="fun"><option value=""><?php esc_html_e( 'Full or partial', 'scholarship-scout' ); ?></option><option value="full"><?php esc_html_e( 'Fully funded only', 'scholarship-scout' ); ?></option></select></label>
				<button type="submit"><?php esc_html_e( 'Show what I can apply for', 'scholarship-scout' ); ?></button>
			</form>
			<div class="ss-elig-out" aria-live="polite"></div>
		</div>
		<style>
		.ss-elig-form{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px;align-items:end;margin-bottom:20px}
		.ss-elig-form label{display:flex;flex-direction:column;gap:6px;font-weight:600;font-size:.92em}
		.ss-elig-form select,.ss-elig-form input{font:inherit;font-weight:400;padding:9px 10px;border:1px solid rgba(127,127,127,.35);border-radius:8px}
		.ss-elig-form button{font:inherit;font-weight:600;padding:10px 16px;border:0;border-radius:8px;background:#0b6e4f;color:#fff;cursor:pointer}
		.ss-elig-out .ss-card{border:1px solid rgba(127,127,127,.3);border-radius:10px;padding:12px 14px;margin-bottom:10px}
		.ss-elig-out .ss-t{font-weight:600}.ss-elig-out .ss-p{opacity:.75;font-size:.9em}.ss-elig-out h3{margin:8px 0 12px}
		</style>
		<script>
		(function(){var w=document.getElementById(<?php echo wp_json_encode( $uid ); ?>);if(!w)return;var D=<?php echo wp_json_encode( $rows ); ?>;
		var AF=['africa','african','developing','global south','low- and middle-income','lmic','any','all nationalities','international','non-eu','non-eea'];
		function esc(s){return String(s||'').replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
		function natOk(n,nat){if(!n)return true;nat=nat.toLowerCase().replace(/\s*\(.*\)/,'');if(n.indexOf(nat)>=0)return true;if(/only|citizens of|nationals of/.test(n)&&n.indexOf('africa')<0)return false;return AF.some(function(a){return n.indexOf(a)>=0;});}
		w.querySelector('form').addEventListener('submit',function(e){e.preventDefault();var f=new FormData(this),nat=f.get('nat'),lvl=f.get('lvl'),fld=(f.get('fld')||'').toLowerCase().trim(),reg=f.get('reg'),fun=f.get('fun');
		var m=D.filter(function(x){return natOk(x.n,nat)&&(!lvl||!x.l||x.l.indexOf(lvl)>=0)&&(!reg||x.r===reg)&&(!fun||x.fu==='full')&&(!fld||!x.f||x.f.indexOf('any')>=0||x.f.indexOf(fld)>=0||x.t.toLowerCase().indexOf(fld)>=0);});
		var o=w.querySelector('.ss-elig-out');if(!m.length){o.innerHTML='<p>'+<?php echo wp_json_encode( __( 'Nothing matches right now. Try fewer filters, and check back: new opportunities are added every day.', 'scholarship-scout' ) ); ?>+'</p>';return;}
		o.innerHTML='<h3>'+<?php echo wp_json_encode( __( 'Opportunities you can look at', 'scholarship-scout' ) ); ?>+'</h3>'+m.slice(0,200).map(function(x){return '<div class="ss-card"><a class="ss-t" href="'+esc(x.u)+'">'+esc(x.t)+'</a><div class="ss-p">'+esc(x.tl)+' · '+esc(x.pr)+' · '+esc(x.c)+(x.d?' · '+esc(x.d==='rolling'?<?php echo wp_json_encode( __( 'Rolling deadline', 'scholarship-scout' ) ); ?>:<?php echo wp_json_encode( __( 'Deadline', 'scholarship-scout' ) ); ?>+' '+x.d):'')+'</div></div>';}).join('')+'<p><small>'+<?php echo wp_json_encode( __( 'Always confirm eligibility on the official page before applying.', 'scholarship-scout' ) ); ?>+'</small></p>';o.scrollIntoView({behavior:'smooth',block:'start'});});})();
		</script>
		<?php
		return ob_get_clean();
	}

	/** Small helper for themes: the next published items by deadline, or the newest. */
	public static function query_items( $pt, $mode = 'soon', $n = 6 ) {
		$today = current_time( 'Y-m-d' );
		if ( 'new' === $mode ) {
			return get_posts( array( 'post_type' => $pt, 'post_status' => 'publish', 'posts_per_page' => $n, 'orderby' => 'date', 'order' => 'DESC' ) );
		}
		return get_posts( array(
			'post_type' => $pt, 'post_status' => 'publish', 'posts_per_page' => $n,
			'meta_key' => 'ss_deadline', 'orderby' => 'meta_value', 'order' => 'ASC',
			'meta_query' => array( array( 'key' => 'ss_deadline', 'value' => $today, 'compare' => '>=' ) ),
		) );
	}

	public static function meta( $id, $k ) {
		return self::m( $id, $k );
	}

	public static function label( $t ) {
		return self::type_label( $t );
	}

	/* ---------- Data for the website app ---------- */

	public static function flush_cache() {
		delete_transient( 'ss_items_v1' );
	}

	public static function register_rest() {
		register_rest_route( 'scholarship-scout/v1', '/items', array(
			'methods'             => 'GET',
			'permission_callback' => '__return_true',
			'callback'            => function () {
				$data = get_transient( 'ss_items_v1' );
				if ( false === $data ) {
					$data = self::public_items();
					set_transient( 'ss_items_v1', $data, 10 * MINUTE_IN_SECONDS );
				}
				$res = new WP_REST_Response( $data );
				$res->header( 'Cache-Control', 'public, max-age=300' );
				return $res;
			},
		) );
	}

	/** Every published item as the website app expects it: the feed data, with your edits on top. */
	public static function public_items() {
		$out  = array( 'opportunities' => array(), 'admissions' => array() );
		$list = array( 'ss_opportunity' => 'levels,fields', 'ss_admission' => 'levels,fields,languages,degree_names' );
		$last = 0;
		foreach ( $list as $pt => $arrays ) {
			$arrays = explode( ',', $arrays );
			foreach ( get_posts( array( 'post_type' => $pt, 'post_status' => 'publish', 'posts_per_page' => -1, 'no_found_rows' => true ) ) as $p ) {
				$raw = json_decode( (string) get_post_meta( $p->ID, '_ss_raw', true ), true );
				$o   = is_array( $raw ) ? $raw : array();
				foreach ( self::fields( $pt ) as $key => $def ) {
					$v = (string) get_post_meta( $p->ID, 'ss_' . $key, true );
					if ( '' === $v ) {
						continue;
					}
					$was = isset( $o[ $key ] ) ? self::flat( $o[ $key ] ) : null;
					if ( $was === $v ) {
						continue; // Unchanged: keep the original shape.
					}
					$o[ $key ] = in_array( $key, $arrays, true ) || ( 'eligible_nationalities' === $key && false !== strpos( $v, ',' ) )
						? array_values( array_filter( array_map( 'trim', explode( ',', $v ) ) ) ) : $v;
				}
				$o['id']       = get_post_meta( $p->ID, '_ss_id', true ) ?: 'wp-' . $p->ID;
				$o['title']    = get_the_title( $p );
				$o['status']   = 'open';
				$o['link']     = get_permalink( $p );
				$o['added_at'] = get_post_time( 'Y-m-d\TH:i:s\Z', true, $p );
				// Summary only: the full write-up is on the article page, not in this public data.
				$intro = (string) ( $o['description'] ?? '' );
				foreach ( array( 'description', 'benefits', 'requirements', 'documents', 'how_to_apply', 'notes', 'selection_process', 'important_dates', 'about_provider', 'source_url', 'added_by', 'deadline_note', 'degree_names_note' ) as $k ) {
					unset( $o[ $k ] );
				}
				if ( 'ss_admission' === $pt ) {
					$o['summary'] = wp_trim_words( $intro, 30 );
					if ( ! empty( $o['financial_aid'] ) ) {
						$o['financial_aid'] = 'yes';
					}
					if ( ! empty( $o['origin_notes'] ) && is_array( $o['origin_notes'] ) ) {
						$o['origin_notes'] = array_map( function ( $n ) { return array( 'countries' => $n['countries'] ?? null, 'note' => '' ); }, $o['origin_notes'] );
					}
				}
				$img = get_the_post_thumbnail_url( $p, 'ss-card' );
				if ( $img ) {
					$o['image'] = $img;
				}
				if ( 'ss_admission' === $pt ) {
					$o['university'] = $o['university'] ?? '';
					$out['admissions'][] = $o;
				} else {
					$o['provider'] = $o['provider'] ?? '';
					$out['opportunities'][] = $o;
				}
				$last = max( $last, strtotime( $p->post_modified_gmt . ' UTC' ) );
			}
		}
		$st            = get_option( self::STATUS );
		$out['status'] = array( 'last_run_at' => gmdate( 'Y-m-d\TH:i:s\Z', max( $last, $st['time'] ?? 0 ) ) );
		return $out;
	}


	/* ---------- Website app (same design as the Scholarship Scout page) and automatic updates ---------- */

	private static function manifest( $fresh = false ) {
		$m = $fresh ? false : get_transient( 'ss_manifest' );
		if ( false === $m ) {
			$res = wp_remote_get( trailingslashit( self::settings()['feed_base'] ) . 'site/manifest.json?t=' . time(), array( 'timeout' => 15 ) );
			$m   = ( ! is_wp_error( $res ) && 200 === wp_remote_retrieve_response_code( $res ) ) ? json_decode( wp_remote_retrieve_body( $res ), true ) : null;
			$m   = is_array( $m ) ? $m : array();
			set_transient( 'ss_manifest', $m, 10 * MINUTE_IN_SECONDS );
		}
		return $m;
	}

	/** Downloads a newer design (app.css, app.js, app.html) from the feed when one is published. */
	public static function sync_app() {
		$m   = self::manifest( true );
		$ver = isset( $m['app_version'] ) ? preg_replace( '/[^0-9A-Za-z._-]/', '', (string) $m['app_version'] ) : '';
		if ( '' === $ver || get_option( 'ss_app_version' ) === $ver ) {
			return '';
		}
		$base  = trailingslashit( self::settings()['feed_base'] ) . 'site/';
		$files = array();
		foreach ( array( 'app.css', 'app.js', 'app.html' ) as $f ) {
			$res = wp_remote_get( $base . $f . '?v=' . rawurlencode( $ver ), array( 'timeout' => 30 ) );
			if ( is_wp_error( $res ) || 200 !== wp_remote_retrieve_response_code( $res ) || strlen( wp_remote_retrieve_body( $res ) ) < 200 ) {
				return '';
			}
			$files[ $f ] = wp_remote_retrieve_body( $res );
		}
		if ( false === strpos( $files['app.js'], 'renderAll' ) || false === strpos( $files['app.html'], 'id="v-discover"' ) ) {
			return ''; // Not a valid design bundle: keep the current one.
		}
		$up  = wp_upload_dir();
		$dir = trailingslashit( $up['basedir'] ) . 'scholarship-scout/' . $ver;
		if ( ! wp_mkdir_p( $dir ) ) {
			return '';
		}
		foreach ( $files as $f => $body ) {
			file_put_contents( $dir . '/' . $f, $body ); // phpcs:ignore
		}
		update_option( 'ss_app_version', $ver );
		return $ver;
	}

	/** Where the current design files live: the downloaded version, or the copy inside this plugin. */
	public static function app_file( $f, $as_url = true ) {
		$ver = get_option( 'ss_app_version' );
		if ( $ver ) {
			$up   = wp_upload_dir();
			$path = trailingslashit( $up['basedir'] ) . 'scholarship-scout/' . $ver . '/' . $f;
			if ( file_exists( $path ) ) {
				return $as_url ? trailingslashit( $up['baseurl'] ) . 'scholarship-scout/' . $ver . '/' . $f : $path;
			}
		}
		return $as_url ? plugins_url( 'app/' . $f, __FILE__ ) : __DIR__ . '/app/' . $f;
	}

	public static function enqueue_app_style() {
		wp_enqueue_style( 'ss-fonts', 'https://fonts.googleapis.com/css2?family=Geist:wght@400;500;600;700&family=Geist+Mono:wght@500&family=Instrument+Serif:ital@0;1&display=swap', array(), null );
		wp_enqueue_style( 'ss-app', self::app_file( 'app.css' ), array(), get_option( 'ss_app_version', '1' ) );
	}

	/** Prints the whole website app (Discover, Open admissions, Eligibility check, Saved). */
	public static function render_app() {
		wp_enqueue_script( 'ss-app', self::app_file( 'app.js' ), array(), get_option( 'ss_app_version', '1' ), true );
		wp_add_inline_script( 'ss-app', 'window.SW=' . wp_json_encode( array( 'api' => rest_url( 'scholarship-scout/v1/items' ), 'home' => home_url( '/' ) ) ) . ';', 'before' );
		echo file_get_contents( self::app_file( 'app.html', false ) ); // phpcs:ignore -- our own design file
	}

	public static function offer_plugin_update( $t ) {
		if ( ! is_object( $t ) ) {
			return $t;
		}
		$m = self::manifest();
		if ( ! function_exists( 'get_plugin_data' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$cur = get_plugin_data( __FILE__, false, false )['Version'];
		if ( ! empty( $m['plugin_version'] ) && ! empty( $m['plugin_zip'] ) && version_compare( $m['plugin_version'], $cur, '>' ) ) {
			$slug                  = plugin_basename( __FILE__ );
			$t->response[ $slug ] = (object) array(
				'slug'        => 'scholarship-scout-importer',
				'plugin'      => $slug,
				'new_version' => $m['plugin_version'],
				'package'     => trailingslashit( self::settings()['feed_base'] ) . 'site/' . $m['plugin_zip'],
				'url'         => 'https://github.com/mbuwul/scholarship-feed',
			);
		}
		return $t;
	}

	public static function offer_theme_update( $t ) {
		if ( ! is_object( $t ) ) {
			return $t;
		}
		$m     = self::manifest();
		$theme = wp_get_theme( 'scholarwise' );
		if ( $theme->exists() && ! empty( $m['theme_version'] ) && ! empty( $m['theme_zip'] ) && version_compare( $m['theme_version'], $theme->get( 'Version' ), '>' ) ) {
			$t->response['scholarwise'] = array(
				'theme'       => 'scholarwise',
				'new_version' => $m['theme_version'],
				'package'     => trailingslashit( self::settings()['feed_base'] ) . 'site/' . $m['theme_zip'],
				'url'         => 'https://github.com/mbuwul/scholarship-feed',
			);
		}
		return $t;
	}


	/* ---------- Cover pictures ---------- */

	private static function hex( $im, $hex, $alpha = 0 ) {
		$hex = ltrim( $hex, '#' );
		return imagecolorallocatealpha( $im, hexdec( substr( $hex, 0, 2 ) ), hexdec( substr( $hex, 2, 2 ) ), hexdec( substr( $hex, 4, 2 ) ), $alpha );
	}

	private static function wrap( $text, $font, $size, $width, $max_lines ) {
		$words = preg_split( '/\s+/u', trim( $text ) );
		$lines = array();
		$line  = '';
		foreach ( $words as $w ) {
			$try = '' === $line ? $w : $line . ' ' . $w;
			$box = imagettfbbox( $size, 0, $font, $try );
			if ( ( $box[2] - $box[0] ) > $width && '' !== $line ) {
				$lines[] = $line;
				$line    = $w;
			} else {
				$line = $try;
			}
		}
		if ( '' !== $line ) {
			$lines[] = $line;
		}
		if ( count( $lines ) > $max_lines ) {
			$lines                    = array_slice( $lines, 0, $max_lines );
			$lines[ $max_lines - 1 ] = rtrim( $lines[ $max_lines - 1 ], ' ,.;:' ) . '…';
		}
		return $lines;
	}

	private static function cover_sig( $post_id ) {
		return md5( implode( '|', array( get_the_title( $post_id ), self::m( $post_id, 'deadline' ), self::m( $post_id, 'type' ), self::m( $post_id, 'host_country' ), self::m( $post_id, 'program_country' ), self::m( $post_id, 'provider' ), self::m( $post_id, 'university' ), self::m( $post_id, 'funding' ), 'v1' ) ) );
	}

	/** Draws an original 1200x630 cover for the post and sets it as its featured image (unless you chose your own). */
	public static function make_cover( $post_id ) {
		if ( ! function_exists( 'imagecreatetruecolor' ) || ! function_exists( 'imagettftext' ) ) {
			return false;
		}
		$thumb = get_post_thumbnail_id( $post_id );
		if ( $thumb && ! get_post_meta( $thumb, '_ss_cover', true ) ) {
			return false; // You picked a picture yourself: keep it.
		}
		$sig = self::cover_sig( $post_id );
		if ( $thumb && get_post_meta( $post_id, '_ss_cover_sig', true ) === $sig ) {
			return false;
		}
		$pt    = get_post_type( $post_id );
		$adm   = 'ss_admission' === $pt;
		$type  = $adm ? 'admission' : self::m( $post_id, 'type' );
		$hues  = array( 'scholarship' => '#2F66E8', 'fellowship' => '#7C3AED', 'internship' => '#0F9F8F', 'conference' => '#E0782A', 'call_for_papers' => '#C2417A', 'grant' => '#3E9B3E', 'admission' => '#0E7AB8' );
		$hue   = $hues[ $type ] ?? '#2F66E8';
		$bold  = __DIR__ . '/fonts/DejaVuSans-Bold.ttf';
		$reg   = __DIR__ . '/fonts/DejaVuSans.ttf';
		$w     = 1200;
		$h     = 630;
		$im    = imagecreatetruecolor( $w, $h );
		imagealphablending( $im, true );
		// Background: deep ink gradient.
		for ( $y = 0; $y < $h; $y++ ) {
			$t = $y / $h;
			imageline( $im, 0, $y, $w, $y, imagecolorallocate( $im, (int) ( 11 + 8 * $t ), (int) ( 27 + 13 * $t ), (int) ( 52 + 22 * $t ) ) );
		}
		// Soft glow in the category colour.
		for ( $r = 520; $r > 0; $r -= 8 ) {
			imagefilledellipse( $im, 1080, 40, $r * 2, $r * 2, self::hex( $im, $hue, (int) max( 100, 127 - ( 520 - $r ) / 12 ) ) );
		}
		// Graduation-cap mark, bottom left.
		imagefilledrectangle( $im, 70, 540, 112, 582, self::hex( $im, '#2F66E8' ) );
		imagesetthickness( $im, 3 );
		$white = self::hex( $im, '#FFFFFF' );
		imagepolygon( $im, array( 77, 556, 91, 549, 105, 556, 91, 563 ), $white );
		imageline( $im, 82, 559, 82, 568, $white );
		imageline( $im, 100, 559, 100, 568, $white );
		imagettftext( $im, 22, 0, 128, 571, $white, $bold, 'Scholar Wise' );
		imagettftext( $im, 22, 0, 128 + ( imagettfbbox( 22, 0, $bold, 'Scholar Wise ' )[2] ), 571, self::hex( $im, '#8FB0FF' ), $bold, 'Africa' );
		// Category pill.
		$label   = $adm ? __( 'OPEN ADMISSION', 'scholarship-scout' ) : strtoupper( self::type_label( $type ) );
		$country = $adm ? self::m( $post_id, 'program_country' ) : self::m( $post_id, 'host_country' );
		$pill    = $label . ( $country ? '  ·  ' . strtoupper( $country ) : '' );
		$pb      = imagettfbbox( 17, 0, $bold, $pill );
		imagefilledrectangle( $im, 70, 64, 70 + ( $pb[2] - $pb[0] ) + 36, 106, self::hex( $im, $hue ) );
		imagettftext( $im, 17, 0, 88, 93, $white, $bold, $pill );
		if ( 'full' === self::m( $post_id, 'funding' ) ) {
			$x  = 70 + ( $pb[2] - $pb[0] ) + 50;
			$fb = imagettfbbox( 17, 0, $bold, __( 'FULLY FUNDED', 'scholarship-scout' ) );
			imagefilledrectangle( $im, $x, 64, $x + ( $fb[2] - $fb[0] ) + 36, 106, self::hex( $im, '#16794A' ) );
			imagettftext( $im, 17, 0, $x + 18, 93, $white, $bold, __( 'FULLY FUNDED', 'scholarship-scout' ) );
		}
		// Title, sized to fit.
		$title = html_entity_decode( get_the_title( $post_id ), ENT_QUOTES, 'UTF-8' );
		foreach ( array( 54, 48, 42, 38 ) as $size ) {
			$lines = self::wrap( $title, $bold, $size, 1050, 4 );
			if ( count( $lines ) <= 3 || 38 === $size ) {
				break;
			}
		}
		$y = 180 + $size;
		foreach ( $lines as $ln ) {
			imagettftext( $im, $size, 0, 70, $y, $white, $bold, $ln );
			$y += (int) ( $size * 1.32 );
		}
		$sub = $adm ? self::m( $post_id, 'university' ) : self::m( $post_id, 'provider' );
		if ( $sub ) {
			$sl = self::wrap( $sub, $reg, 24, 1050, 1 );
			imagettftext( $im, 24, 0, 70, $y + 10, self::hex( $im, '#A9B5C9' ), $reg, $sl[0] );
		}
		// Deadline, bottom right.
		$dl = self::m( $post_id, 'deadline' );
		$dt = 'rolling' === $dl ? __( 'Rolling deadline', 'scholarship-scout' ) : ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $dl ) ? sprintf( __( 'Deadline: %s', 'scholarship-scout' ), wp_date( 'j M Y', strtotime( $dl . ' 12:00:00' ) ) ) : '' );
		if ( $dt ) {
			$db = imagettfbbox( 24, 0, $bold, $dt );
			imagettftext( $im, 24, 0, $w - 70 - ( $db[2] - $db[0] ), 571, self::hex( $im, '#FFC069' ), $bold, $dt );
		}
		// Save into the media library.
		$up   = wp_upload_dir();
		$dir  = trailingslashit( $up['basedir'] ) . 'scholarship-scout/covers';
		wp_mkdir_p( $dir );
		$name = sanitize_file_name( get_post_field( 'post_name', $post_id ) ?: 'item-' . $post_id ) . '-' . substr( $sig, 0, 6 ) . '.jpg';
		$file = $dir . '/' . $name;
		imagejpeg( $im, $file, 86 );
		imagedestroy( $im );
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$att = wp_insert_attachment( array(
			'post_mime_type' => 'image/jpeg',
			'post_title'     => get_the_title( $post_id ),
			'post_status'    => 'inherit',
		), $file, $post_id );
		if ( is_wp_error( $att ) || ! $att ) {
			return false;
		}
		update_post_meta( $att, '_ss_cover', 1 );
		update_post_meta( $att, '_wp_attachment_image_alt', get_the_title( $post_id ) );
		wp_update_attachment_metadata( $att, wp_generate_attachment_metadata( $att, $file ) );
		set_post_thumbnail( $post_id, $att );
		update_post_meta( $post_id, '_ss_cover_sig', $sig );
		do_action( 'ss_cover_ready', $post_id );
		if ( $thumb && $thumb !== $att ) {
			wp_delete_attachment( $thumb, true ); // Old cover of ours.
		}
		return true;
	}

	/** Gives covers to items that have none yet (or whose title or deadline changed), a few per run. */
	public static function backfill_covers( $limit ) {
		$done = 0;
		foreach ( array( 'publish', array( 'draft', 'pending', 'future' ) ) as $status ) {
			$left = $limit - $done;
			if ( $left <= 0 ) {
				break;
			}
			$ids = get_posts( array(
				'post_type' => array_keys( self::kinds() ), 'post_status' => $status,
				'posts_per_page' => $left, 'fields' => 'ids', 'no_found_rows' => true,
				'meta_query' => array( array( 'key' => '_thumbnail_id', 'compare' => 'NOT EXISTS' ) ),
			) );
			foreach ( $ids as $id ) {
				if ( self::make_cover( $id ) ) {
					$done++;
				}
			}
		}
		return $done;
	}

	/** A cover the moment you publish an item, if it has none yet. */
	public static function cover_on_publish( $new, $old, $post ) {
		if ( 'publish' === $new && isset( self::kinds()[ $post->post_type ] ) && ! has_post_thumbnail( $post->ID ) ) {
			self::make_cover( $post->ID );
		}
	}

	/* ---------- Protection ---------- */

	/** Makes casual copying hard: no selecting, copying, right-click or dragging images. Logged-in editors are not affected. */
	public static function copy_protection() {
		if ( empty( self::settings()['protect'] ) || current_user_can( 'edit_posts' ) ) {
			return;
		}
		wp_register_style( 'ss-protect', false, array(), '1' );
		wp_enqueue_style( 'ss-protect' );
		wp_add_inline_style( 'ss-protect', 'body{-webkit-user-select:none;-moz-user-select:none;user-select:none;-webkit-touch-callout:none}input,textarea,select,[contenteditable]{-webkit-user-select:text;user-select:text}img{-webkit-user-drag:none;user-drag:none}@media print{body{display:none!important}}' );
		wp_register_script( 'ss-protect', false, array(), '1', true );
		wp_enqueue_script( 'ss-protect' );
		wp_add_inline_script( 'ss-protect', '(function(){var f=function(e){var t=e.target;return t&&(t.closest&&t.closest("input,textarea,select,[contenteditable]"));};["contextmenu","dragstart","selectstart","cut"].forEach(function(n){document.addEventListener(n,function(e){if(!f(e))e.preventDefault();});});document.addEventListener("copy",function(e){if(f(e))return;e.preventDefault();try{e.clipboardData.setData("text/plain","Read it on Scholar Wise Africa: "+location.href);}catch(x){}});document.addEventListener("keydown",function(e){var k=(e.key||"").toLowerCase();if((e.ctrlKey||e.metaKey)&&["c","x","s","u","p","a"].indexOf(k)>-1&&!f(e)){e.preventDefault();}if(k==="f12"||((e.ctrlKey||e.metaKey)&&e.shiftKey&&["i","j","c"].indexOf(k)>-1)){e.preventDefault();}});})();' );
	}

	/** The built-in WordPress data API stays available to you in the dashboard, but not to the public. */
	public static function guard_core_rest( $result, $server, $request ) {
		$route = $request->get_route();
		if ( preg_match( '#^/wp/v2/(ss_opportunity|ss_admission)#', $route ) && ! current_user_can( 'edit_posts' ) ) {
			return new WP_Error( 'rest_forbidden', __( 'Not available.', 'scholarship-scout' ), array( 'status' => 401 ) );
		}
		return $result;
	}

	/** No RSS copies of the opportunities. */
	public static function block_feeds() {
		if ( is_feed() && ( is_post_type_archive( array_keys( self::kinds() ) ) || is_singular( array_keys( self::kinds() ) ) ) ) {
			wp_safe_redirect( home_url( '/' ), 301 );
			exit;
		}
	}

	/** Sends your GitHub token with feed and update downloads, so the feed repository can be private. */
	public static function github_auth( $args, $url ) {
		$s    = self::settings();
		$base = trailingslashit( $s['feed_base'] );
		if ( ! empty( $s['token'] ) && 0 === strpos( $url, $base ) ) {
			$args['headers']                  = isset( $args['headers'] ) && is_array( $args['headers'] ) ? $args['headers'] : array();
			$args['headers']['Authorization'] = 'token ' . $s['token'];
		}
		return $args;
	}

}

Scholarship_Scout_Importer::init();
if ( file_exists( __DIR__ . '/includes/seo.php' ) ) {
	require __DIR__ . '/includes/seo.php';
}
register_activation_hook( __FILE__, array( 'Scholarship_Scout_Importer', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'Scholarship_Scout_Importer', 'deactivate' ) );
