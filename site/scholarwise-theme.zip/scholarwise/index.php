<?php get_header(); get_template_part( 'page-bar' ); ?>
<main class="wrap sw-page">
	<h1><?php echo is_404() ? esc_html__( 'Page not found', 'scholarwise' ) : esc_html( wp_strip_all_tags( get_the_archive_title() ) ); ?></h1>
	<div class="sw-card">
	<?php if ( have_posts() && ! is_404() ) : while ( have_posts() ) : the_post(); ?>
		<p><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></p>
	<?php endwhile; else : ?>
		<p><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Browse opportunities', 'scholarwise' ); ?></a></p>
	<?php endif; ?>
	</div>
</main>
<?php get_footer(); ?>
