<?php
get_header();
if ( scholarwise_has_plugin() ) {
	Scholarship_Scout_Importer::render_app();
} else {
	get_template_part( 'page-bar' );
	echo '<main class="wrap sw-page"><div class="sw-card"><p>' . esc_html__( 'Activate the Scholarship Scout Importer plugin to show opportunities here.', 'scholarwise' ) . '</p></div></main>';
}
get_footer();
