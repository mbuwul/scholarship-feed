<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'after_setup_theme', function () {
	add_theme_support( 'title-tag' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script' ) );
} );

function scholarwise_has_plugin() {
	return class_exists( 'Scholarship_Scout_Importer' ) && method_exists( 'Scholarship_Scout_Importer', 'render_app' );
}

add_action( 'wp_enqueue_scripts', function () {
	if ( scholarwise_has_plugin() ) {
		Scholarship_Scout_Importer::enqueue_app_style();
	}
	wp_enqueue_style( 'scholarwise', get_stylesheet_uri(), array(), wp_get_theme()->get( 'Version' ) );
} );

/** Old list pages now live inside the app on the home page. */
add_action( 'template_redirect', function () {
	if ( is_post_type_archive( 'ss_opportunity' ) ) {
		$q = isset( $_GET['q'] ) ? '?q=' . rawurlencode( sanitize_text_field( wp_unslash( $_GET['q'] ) ) ) : '';
		wp_safe_redirect( home_url( '/' ) . $q, 301 );
		exit;
	}
	if ( is_post_type_archive( 'ss_admission' ) ) {
		wp_safe_redirect( home_url( '/#admissions' ), 301 );
		exit;
	}
	if ( is_page( 'eligibility' ) ) {
		wp_safe_redirect( home_url( '/#eligibility' ), 301 );
		exit;
	}
} );

add_filter( 'pre_get_document_title', function ( $t ) {
	return is_front_page() ? 'Scholar Wise Africa · Scholarships and opportunities for African students' : $t;
} );

add_action( 'wp_head', function () {
	if ( is_front_page() ) {
		echo '<meta name="description" content="' . esc_attr__( 'Scholarships, fellowships, internships, funded conferences, calls for papers, grants and open admissions for African students in Europe, Asia and North America. Updated every hour.', 'scholarwise' ) . '">' . "\n";
	}
}, 1 );

/** Starter pages, permalinks and site name, the first time the theme is switched on. */
add_action( 'after_switch_theme', function () {
	if ( ! get_option( 'permalink_structure' ) ) {
		update_option( 'permalink_structure', '/%postname%/' );
	}
	foreach ( array(
		'about'   => array( __( 'About', 'scholarwise' ), '<p>Scholar Wise Africa helps African students find scholarships, fellowships, internships, funded conferences, calls for papers, grants and open admissions in Europe, Asia and North America.</p><p>New opportunities are found every hour, and each one is checked before it is published here. Always confirm the details on the official page before you apply.</p>' ),
		'contact' => array( __( 'Contact', 'scholarwise' ), '<p>Questions, corrections or an opportunity to share? Write to us at <strong>[add your email address here]</strong>.</p>' ),
	) as $slug => $pg ) {
		if ( ! get_page_by_path( $slug ) ) {
			wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_name' => $slug, 'post_title' => $pg[0], 'post_content' => $pg[1] ) );
		}
	}
	update_option( 'blogname', 'Scholar Wise Africa' );
	flush_rewrite_rules();
} );
