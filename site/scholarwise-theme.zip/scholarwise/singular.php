<?php get_header(); get_template_part( 'page-bar' ); ?>
<main class="wrap sw-page">
<?php while ( have_posts() ) : the_post(); ?>
	<?php $sw_item = in_array( get_post_type(), array( 'ss_opportunity', 'ss_admission' ), true ); ?>
	<?php if ( $sw_item ) : ?>
		<a class="back" href="<?php echo esc_url( home_url( 'ss_admission' === get_post_type() ? '/#admissions' : '/' ) ); ?>">&larr; <?php echo esc_html( 'ss_admission' === get_post_type() ? __( 'All open admissions', 'scholarwise' ) : __( 'All opportunities', 'scholarwise' ) ); ?></a>
	<?php endif; ?>
	<article <?php post_class( 'sw-article' ); ?>>
		<?php do_action( 'sw_before_article', get_the_ID() ); ?>
		<h1><?php the_title(); ?></h1>
		<?php if ( $sw_item && has_post_thumbnail() ) : ?>
			<?php the_post_thumbnail( 'full', array( 'class' => 'sw-hero-img', 'alt' => get_the_title(), 'loading' => 'eager', 'fetchpriority' => 'high', 'draggable' => 'false' ) ); ?>
		<?php endif; ?>
		<div class="sw-card"><?php the_content(); ?></div>
		<?php do_action( 'sw_after_article', get_the_ID() ); ?>
	</article>
<?php endwhile; ?>
</main>
<?php get_footer(); ?>
