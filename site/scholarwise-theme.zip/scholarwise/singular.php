<?php get_header(); get_template_part( 'page-bar' ); ?>
<main class="wrap sw-page">
<?php while ( have_posts() ) : the_post(); ?>
	<?php $sw_item = in_array( get_post_type(), array( 'ss_opportunity', 'ss_admission' ), true ); ?>
	<?php if ( $sw_item ) : ?>
		<a class="back" href="<?php echo esc_url( home_url( 'ss_admission' === get_post_type() ? '/#admissions' : '/' ) ); ?>">&larr; <?php echo esc_html( 'ss_admission' === get_post_type() ? __( 'All open admissions', 'scholarwise' ) : __( 'All opportunities', 'scholarwise' ) ); ?></a>
		<article <?php post_class( 'sw-article' ); ?>>
			<?php do_action( 'sw_before_article', get_the_ID() ); ?>
			<?php
			if ( class_exists( 'Scholarship_Scout_Importer' ) && method_exists( 'Scholarship_Scout_Importer', 'photo_html' ) ) {
				the_content(); // The plugin lays out the whole article: title, picture, sections, key facts.
			} else {
				echo '<h1>' . esc_html( get_the_title() ) . '</h1>';
				if ( has_post_thumbnail() ) {
					the_post_thumbnail( 'full', array( 'class' => 'sw-hero-img', 'alt' => get_the_title() ) );
				}
				echo '<div class="sw-card">';
				the_content();
				echo '</div>';
			}
			?>
			<?php do_action( 'sw_after_article', get_the_ID() ); ?>
		</article>
	<?php else : ?>
		<article <?php post_class( 'sw-article' ); ?>>
			<h1><?php the_title(); ?></h1>
			<div class="sw-card"><?php the_content(); ?></div>
		</article>
	<?php endif; ?>
<?php endwhile; ?>
</main>
<?php get_footer(); ?>
