<?php get_header(); get_template_part( 'page-bar' ); ?>
<main class="wrap sw-page">
<?php while ( have_posts() ) : the_post(); ?>
	<?php if ( in_array( get_post_type(), array( 'ss_opportunity', 'ss_admission' ), true ) ) : ?>
		<a class="back" href="<?php echo esc_url( home_url( 'ss_admission' === get_post_type() ? '/#admissions' : '/' ) ); ?>">&larr; <?php echo esc_html( 'ss_admission' === get_post_type() ? __( 'All open admissions', 'scholarwise' ) : __( 'All opportunities', 'scholarwise' ) ); ?></a>
	<?php endif; ?>
	<h1><?php the_title(); ?></h1>
	<div class="sw-card"><?php the_content(); ?></div>
<?php endwhile; ?>
</main>
<?php get_footer(); ?>
