<?php /* Top bar for inner pages: same look as the app's bar, with links back into the app. On phones the links sit in a menu that slides in from the left. */ ?>
<header class="appbar">
	<div class="wrap">
		<button class="sw-burger" type="button" aria-label="<?php esc_attr_e( 'Menu', 'scholarwise' ); ?>" aria-expanded="false" aria-controls="swNav"><span></span><span></span><span></span></button>
		<a class="logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php esc_attr_e( 'Scholar Wise Africa home', 'scholarwise' ); ?>">
			<span class="mark"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M2 9.5 12 5l10 4.5-10 4.5z"/><path d="M6 11.5v4.5c0 1.4 2.7 3 6 3s6-1.6 6-3v-4.5"/><path d="M22 9.5v5"/></svg></span>
			<b>Scholar Wise <span style="color:var(--accent)">Africa</span></b>
		</a>
		<nav class="tabs" id="swNav" aria-label="<?php esc_attr_e( 'Sections', 'scholarwise' ); ?>">
			<a class="tablink" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Discover', 'scholarwise' ); ?></a>
			<a class="tablink" href="<?php echo esc_url( home_url( '/#eligibility' ) ); ?>"><?php esc_html_e( 'Eligibility check', 'scholarwise' ); ?></a>
			<a class="tablink" href="<?php echo esc_url( home_url( '/#saved' ) ); ?>"><?php esc_html_e( 'Saved', 'scholarwise' ); ?></a>
		</nav>
	</div>
</header>
<div class="sw-scrim"></div>
<script>(function(){var b=document.querySelector(".appbar .sw-burger"),bar=b&&b.closest(".appbar"),s=document.querySelector(".sw-scrim");if(!b)return;function set(o){bar.classList.toggle("sw-open",o);document.body.classList.toggle("sw-menu-open",o);b.setAttribute("aria-expanded",o?"true":"false");}b.addEventListener("click",function(){set(!bar.classList.contains("sw-open"));});s.addEventListener("click",function(){set(false);});})();</script>
