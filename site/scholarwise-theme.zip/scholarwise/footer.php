<footer class="sw-foot">
	<div class="wrap">
		<div>&copy; <?php echo esc_html( wp_date( 'Y' ) ); ?> Scholar Wise Africa. <?php esc_html_e( 'Always confirm details on the official page before applying.', 'scholarwise' ); ?></div>
		<div><a href="<?php echo esc_url( home_url( '/about/' ) ); ?>"><?php esc_html_e( 'About', 'scholarwise' ); ?></a> · <a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"><?php esc_html_e( 'Contact', 'scholarwise' ); ?></a></div>
	</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
